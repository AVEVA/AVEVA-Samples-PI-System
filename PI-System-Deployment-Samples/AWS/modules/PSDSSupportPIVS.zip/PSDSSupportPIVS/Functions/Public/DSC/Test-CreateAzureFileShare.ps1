<#
.SYNOPSIS
    This function tests for an Azure file share using the Azure REST API.
.DESCRIPTION
    This function tests for the existence of an Azure File Share. It runs under the presumption that a virtual machine has a Managed Service Account
    VM extension installed and that said account has sufficient rights to the target storage account.
.EXAMPLE
    This example show the test for an Azure File Share's existence with Verbose switched on to show the returning output. The output object is a boolean.
    Test-CreateAzureFileShare -subscriptionId $subscriptionId -storageResourceGroup $storageResoruceGroup -storageAccount $storageAccount -storageShare $storageShare -Verbose
        VERBOSE: Getting Azure VM Managed Service identity (MSI) Bearer Token.
        VERBOSE: GET http://localhost:50342/oauth2/token?resource=https:%2F%2Fmanagement.azure.com%2F with 0-byte payload
        VERBOSE: received 1335-byte response of content type application/json
        VERBOSE: Getting Storage Key for storage account where File Share will be created.
        VERBOSE: POST https://management.azure.com/subscriptions/28fb33dd-25f0-49a0-926f-72236b87290b/resourceGroups/test42-hostedpi-test-rg/providers/Microsoft.Storage/storageAccounts/tststdjg4jfwskst/listKeys/?api-version=2017-10-01 with 0-byte payload
        VERBOSE: received 288-byte response of content type application/json
        VERBOSE: Generating request header.
        VERBOSE: Executing GET call to check for share.
        VERBOSE: Share URI: https://tststdjg4jfwskst.file.core.windows.net/witness?restype=share.
        VERBOSE: GET https://tststdjg4jfwskst.file.core.windows.net/witness?restype=share with 0-byte payload
        VERBOSE: received -1-byte response of content type 
        VERBOSE: Share found. Status Code: 200
    True
.NOTES
    This function tests for an Azure File Share. It's intended purpose is to be utilized by the corresponding DSC Configuration resource used by OSIsoft
    Hosted PI deployments. To avoid embedded credentials in scripts, this function leverages the Azure REST API to generate a call to create the Azure File Share.
    As prerequisite, it requires the virtual machine on which it is execute to have a Managed Service Identity (MSI) VM extension installed. Also, the VM's MSI must have
    sufficient permissions to modify the storage account resource. (If using the built in RBAC roles in Azure, you can use the Contributor role, but ensure 
    it is scoped to the target storage account only!). The test makes a GET call for the specified Azure File Share properties as this is a more explciti call for 
    a specific Azure File Share instance.
#>
function Test-CreateAzureFileShare {
    [CmdletBinding()]
    [OutputType([boolean])]
    param(
        # Subscription ID containing storage account for file share.
        [Parameter(Mandatory = $true)]
        [string]$subscriptionId,

        # Resource Group containing storage account.
        [Parameter(Mandatory = $true)]
        $storageResourceGroup,
        
        # Storage account for file share.
        [Parameter(Mandatory = $true)]
        $storageAccount,

        # Name for File Share
        [Parameter(Mandatory = $true)]
        $storageShare
    )

    begin {
        Try {
            # Get Bearer Token
            Write-Verbose -Message "Getting Azure VM Managed Service identity (MSI) Bearer Token." -Verbose
            $response = Invoke-WebRequest -Uri http://localhost:50342/oauth2/token -Method GET -UseBasicParsing -Body @{resource = "https://management.azure.com/"} -Headers @{Metadata = "true"}
            $content = $response.Content | ConvertFrom-Json
            $ArmToken = $content.access_token
        }

        Catch {
            Write-Error $_
            throw 'Unable to Azure VM Managed Service identity (MSI) Bearer Token. See error for details.'
        }

    }

    process {
        Try {
            # Get Primary Key from Storage Account
            Write-Verbose -Message "Getting Storage Key for storage account where File Share will be created." -Verbose
            $keysResponse = Invoke-WebRequest -Uri "https://management.azure.com/subscriptions/$subscriptionId/resourceGroups/$storageResourceGroup/providers/Microsoft.Storage/storageAccounts/$storageAccount/listKeys/?api-version=2017-10-01" -Method POST -UseBasicParsing -Headers @{Authorization = "Bearer $ARMToken"}
            $keysContent = $keysResponse.Content | ConvertFrom-Json
            $storageKey = $keysContent.keys[0].value  # Account Key
        }

        Catch {
            Write-Error $_
            throw 'Unable to Azure Storage Account Key. See error for details.'
        }


        Try {
            # Build CanonicalizedHeaders for REST API call.
            Write-Verbose -Message "Generating request header." -Verbose
            $headers = @{}
            $headers.Add("x-ms-version", "2017-04-17")               # API Version
            [DateTime]$UtcTime = (Get-Date ).ToUniversalTime()
            $headerDate = (Get-Date -Date $UtcTime -Format r)
            $headers.Add("x-ms-date", "$headerDate")                 # Request date in UTC and RFC1123 format

            # Build Signature String
            $signatureString = "GET$([char]10)$([char]10)$([char]10)$([char]10)$([char]10)$([char]10)$([char]10)$([char]10)$([char]10)$([char]10)$([char]10)$([char]10)"
            $signatureString += "x-ms-date:" + $headers["x-ms-date"] + "$([char]10)"
            $signatureString += "x-ms-version:" + $headers["x-ms-version"] + "$([char]10)"

            # Add CanonicalizedResource
            $signatureString += "/" + $storageAccount + "/" + $storageShare + "$([char]10)" + "restype:share"

            # Encoding Signature
            $dataToMac = [System.Text.Encoding]::UTF8.GetBytes($signatureString)
            $accountKeyBytes = [System.Convert]::FromBase64String($storageKey)
            $hmac = New-Object System.Security.Cryptography.HMACSHA256((, $accountKeyBytes))
            $signature = [System.Convert]::ToBase64String($hmac.ComputeHash($dataToMac))
            $headers.Add("Authorization", "SharedKey " + $StorageAccount + ":" + $signature)   # Add encoded signature to Header
        }

        Catch {
            Write-Error $_
            throw 'Unable to generate REST API headers. See error for details.'
        }


        Try {
            ## This call checks for the Share. Response 200 = Share exists. Exception = Share not Found
            $newShareUri = "https://" + $storageAccount + ".file.core.windows.net/" + $storageShare + "?restype=share"
            Write-Verbose -Message "Executing GET call to check for share." -Verbose
            Write-Verbose -Message "Share URI: $($newShareUri)." -Verbose
            $getResponse = Invoke-WebRequest -Uri $newShareUri -Method GET -UseBasicParsing -Headers $headers -ErrorAction Stop

            # If Share is found, expect a 200 response and return $true
            if ($getResponse.StatusCode -eq 200) {
                Write-Verbose -Message "Share found. Status Code: $($getResponse.StatusCode)" -Verbose
                return $true
            }
            else {
                Write-Verbose -Message "Response returned but not 200. Status Code: $($getResponse.StatusCode)" -Verbose
                return $true
            }
        }

        # If Share not found, expect exception of type System.net.WebException. Indicates share's absence and therefore needs creating.
        Catch [System.Net.WebException] {
            $getErr = $Error[0]
            $shareNotFound = $getErr.ErrorDetails.Message -like "*The specified share does not exist*"
            if ($shareNotFound) {
                Write-Verbose -Message "Share $($storageShare) was not found. Exception thrown with no response." -Verbose
                return $false
            }
            else {
                Write-Warning -Message "Share $($storageShare) was not found." -Verbose
                Write-Warning -Message "Exception: $($getErr.Exception.Message)" -Verbose
                return $false
            }
        }

        # Catch any other error and output
        Catch {
            Write-Error $_
            throw 'Unable to get Azure File Share. See error for details.'
        }
    }

    end {
    }
}
# SIG # Begin signature block
# MIIbywYJKoZIhvcNAQcCoIIbvDCCG7gCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDtYUJa9MNbmUGQ
# fOJ4zseVLHNDIolqf7nU/5KdAWIcqqCCCo4wggUwMIIEGKADAgECAhAECRgbX9W7
# ZnVTQ7VvlVAIMA0GCSqGSIb3DQEBCwUAMGUxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xJDAiBgNV
# BAMTG0RpZ2lDZXJ0IEFzc3VyZWQgSUQgUm9vdCBDQTAeFw0xMzEwMjIxMjAwMDBa
# Fw0yODEwMjIxMjAwMDBaMHIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2Vy
# dCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xMTAvBgNVBAMTKERpZ2lD
# ZXJ0IFNIQTIgQXNzdXJlZCBJRCBDb2RlIFNpZ25pbmcgQ0EwggEiMA0GCSqGSIb3
# DQEBAQUAA4IBDwAwggEKAoIBAQD407Mcfw4Rr2d3B9MLMUkZz9D7RZmxOttE9X/l
# qJ3bMtdx6nadBS63j/qSQ8Cl+YnUNxnXtqrwnIal2CWsDnkoOn7p0WfTxvspJ8fT
# eyOU5JEjlpB3gvmhhCNmElQzUHSxKCa7JGnCwlLyFGeKiUXULaGj6YgsIJWuHEqH
# CN8M9eJNYBi+qsSyrnAxZjNxPqxwoqvOf+l8y5Kh5TsxHM/q8grkV7tKtel05iv+
# bMt+dDk2DZDv5LVOpKnqagqrhPOsZ061xPeM0SAlI+sIZD5SlsHyDxL0xY4PwaLo
# LFH3c7y9hbFig3NBggfkOItqcyDQD2RzPJ6fpjOp/RnfJZPRAgMBAAGjggHNMIIB
# yTASBgNVHRMBAf8ECDAGAQH/AgEAMA4GA1UdDwEB/wQEAwIBhjATBgNVHSUEDDAK
# BggrBgEFBQcDAzB5BggrBgEFBQcBAQRtMGswJAYIKwYBBQUHMAGGGGh0dHA6Ly9v
# Y3NwLmRpZ2ljZXJ0LmNvbTBDBggrBgEFBQcwAoY3aHR0cDovL2NhY2VydHMuZGln
# aWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEUm9vdENBLmNydDCBgQYDVR0fBHow
# eDA6oDigNoY0aHR0cDovL2NybDQuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJl
# ZElEUm9vdENBLmNybDA6oDigNoY0aHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0Rp
# Z2lDZXJ0QXNzdXJlZElEUm9vdENBLmNybDBPBgNVHSAESDBGMDgGCmCGSAGG/WwA
# AgQwKjAoBggrBgEFBQcCARYcaHR0cHM6Ly93d3cuZGlnaWNlcnQuY29tL0NQUzAK
# BghghkgBhv1sAzAdBgNVHQ4EFgQUWsS5eyoKo6XqcQPAYPkt9mV1DlgwHwYDVR0j
# BBgwFoAUReuir/SSy4IxLVGLp6chnfNtyA8wDQYJKoZIhvcNAQELBQADggEBAD7s
# DVoks/Mi0RXILHwlKXaoHV0cLToaxO8wYdd+C2D9wz0PxK+L/e8q3yBVN7Dh9tGS
# dQ9RtG6ljlriXiSBThCk7j9xjmMOE0ut119EefM2FAaK95xGTlz/kLEbBw6RFfu6
# r7VRwo0kriTGxycqoSkoGjpxKAI8LpGjwCUR4pwUR6F6aGivm6dcIFzZcbEMj7uo
# +MUSaJ/PQMtARKUT8OZkDCUIQjKyNookAv4vcn4c10lFluhZHen6dGRrsutmQ9qz
# sIzV6Q3d9gEgzpkxYz0IGhizgZtPxpMQBvwHgfqL2vmCSfdibqFT+hKUGIUukpHq
# aGxEMrJmoecYpJpkUe8wggVWMIIEPqADAgECAhAFTTVZN0yftPMcszD508Q/MA0G
# CSqGSIb3DQEBCwUAMHIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJ
# bmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xMTAvBgNVBAMTKERpZ2lDZXJ0
# IFNIQTIgQXNzdXJlZCBJRCBDb2RlIFNpZ25pbmcgQ0EwHhcNMTkwNjE3MDAwMDAw
# WhcNMjAwNzAxMTIwMDAwWjCBkjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRQw
# EgYDVQQHEwtTYW4gTGVhbmRybzEVMBMGA1UEChMMT1NJc29mdCwgTExDMQwwCgYD
# VQQLEwNEZXYxFTATBgNVBAMTDE9TSXNvZnQsIExMQzEkMCIGCSqGSIb3DQEJARYV
# c21hbmFnZXJzQG9zaXNvZnQuY29tMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIB
# CgKCAQEAqbP+VTz8qtsq4SWhF7LsXqeDGyUwtDpf0vlSg+aQh2fOqJhW2uiPa1GO
# M5+xbr+RhTTWzJX2vEwqSIzN43ktTdgcVT9Bf5W2md+RCYE1D17jGlj5sCFTS4eX
# Htm+lFoQF0donavbA+7+ggd577FdgOnjuYxEpZe2lbUyWcKOHrLQr6Mk/bKjcYSY
# B/ipNK4hvXKTLEsN7k5kyzRkq77PaqbVAQRgnQiv/Lav5xWXuOn7M94TNX4+1Mk8
# 74nuny62KLcMRtjPCc2aWBpHmhD3wPcUVvTW+lGwEaT0DrCwcZDuG/Igkhqj/8Rf
# HYfnZQtWMnBFAHcuA4jJgmZ7xYMPoQIDAQABo4IBxTCCAcEwHwYDVR0jBBgwFoAU
# WsS5eyoKo6XqcQPAYPkt9mV1DlgwHQYDVR0OBBYEFNcTKM3o/Fjj9J3iOakcmKx6
# CPetMA4GA1UdDwEB/wQEAwIHgDATBgNVHSUEDDAKBggrBgEFBQcDAzB3BgNVHR8E
# cDBuMDWgM6Axhi9odHRwOi8vY3JsMy5kaWdpY2VydC5jb20vc2hhMi1hc3N1cmVk
# LWNzLWcxLmNybDA1oDOgMYYvaHR0cDovL2NybDQuZGlnaWNlcnQuY29tL3NoYTIt
# YXNzdXJlZC1jcy1nMS5jcmwwTAYDVR0gBEUwQzA3BglghkgBhv1sAwEwKjAoBggr
# BgEFBQcCARYcaHR0cHM6Ly93d3cuZGlnaWNlcnQuY29tL0NQUzAIBgZngQwBBAEw
# gYQGCCsGAQUFBwEBBHgwdjAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNl
# cnQuY29tME4GCCsGAQUFBzAChkJodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20v
# RGlnaUNlcnRTSEEyQXNzdXJlZElEQ29kZVNpZ25pbmdDQS5jcnQwDAYDVR0TAQH/
# BAIwADANBgkqhkiG9w0BAQsFAAOCAQEAigLIcsGUWzXlZuVQY8s1UOxYgch5qO1Y
# YEDFF8abzJQ4RiB8rcdoRWjsfpWxtGOS0wkA2CfyuWhjO/XqgmYJ8AUHIKKCy6QE
# 31/I6izI6iDCg8X5lSR6nKsB2BCZCOnGJOEi3r+WDS18PMuW24kaBo1ezx6KQOx4
# N0qSrMJqJRXfPHpl3WpcLs3VA1Gew9ATOQ9IXbt8QCvyMICRJxq4heHXPLE3EpK8
# 2wlBKwX3P4phapmEUOWxB45QOcRJqgahe9qIALbLS+i5lxV+eX/87YuEiyDtGfH+
# dAbq5BqlYz1Fr8UrWeR3KIONPNtkm2IFHNMdpsgmKwC/Xh3nC3b27DGCEJMwghCP
# AgEBMIGGMHIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAX
# BgNVBAsTEHd3dy5kaWdpY2VydC5jb20xMTAvBgNVBAMTKERpZ2lDZXJ0IFNIQTIg
# QXNzdXJlZCBJRCBDb2RlIFNpZ25pbmcgQ0ECEAVNNVk3TJ+08xyzMPnTxD8wDQYJ
# YIZIAWUDBAIBBQCggZ4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIOiDcbTIoZNc
# /cHs7MQaTX813Oj4o/5FL/fzxeeEQ++/MDIGCisGAQQBgjcCAQwxJDAioSCAHmh0
# dHA6Ly90ZWNoc3VwcG9ydC5vc2lzb2Z0LmNvbTANBgkqhkiG9w0BAQEFAASCAQCp
# NMS0GfDDoHK7fXjfxiqMiHvr24oOqXMLatff8PLm+zFox2UIqO3oj7guToXBRXAk
# /oQJ/n8scMoWnfsH6SJn58efzCWGpkwsYmh7QQ+0AJ8uUIDZlpF6ZzcFtjQt+qZi
# hQlUpApzDIB7YTlew8+5mgjCvLUUchdGTYBWGYuG0GcuCblP95pu2v22awxuGEn5
# XdbWl08mnj+RKveW0MxJDAmWG7GYkvhZo/0BL6fKcTc6y6ScwE+4qwa3/Nn9Ur5y
# akvBjX2a+OULlZ/HwFYY765eNkTnkvbPbanzOVd05sozYhrWqxhmKCjkzQxZNTFg
# MUILrJElEFdHWOILu+LToYIOPDCCDjgGCisGAQQBgjcDAwExgg4oMIIOJAYJKoZI
# hvcNAQcCoIIOFTCCDhECAQMxDTALBglghkgBZQMEAgEwggEOBgsqhkiG9w0BCRAB
# BKCB/gSB+zCB+AIBAQYLYIZIAYb4RQEHFwMwMTANBglghkgBZQMEAgEFAAQgRQTA
# 4Ps5/NT0DzZGhb1Wouw3ZGWCu2jWLwITI9/8VsUCFBOL6bnV8kNBCr5bcdfP5y69
# DtaXGA8yMDIwMDMyMzE3MzcyOVowAwIBHqCBhqSBgzCBgDELMAkGA1UEBhMCVVMx
# HTAbBgNVBAoTFFN5bWFudGVjIENvcnBvcmF0aW9uMR8wHQYDVQQLExZTeW1hbnRl
# YyBUcnVzdCBOZXR3b3JrMTEwLwYDVQQDEyhTeW1hbnRlYyBTSEEyNTYgVGltZVN0
# YW1waW5nIFNpZ25lciAtIEczoIIKizCCBTgwggQgoAMCAQICEHsFsdRJaFFE98mJ
# 0pwZnRIwDQYJKoZIhvcNAQELBQAwgb0xCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5W
# ZXJpU2lnbiwgSW5jLjEfMB0GA1UECxMWVmVyaVNpZ24gVHJ1c3QgTmV0d29yazE6
# MDgGA1UECxMxKGMpIDIwMDggVmVyaVNpZ24sIEluYy4gLSBGb3IgYXV0aG9yaXpl
# ZCB1c2Ugb25seTE4MDYGA1UEAxMvVmVyaVNpZ24gVW5pdmVyc2FsIFJvb3QgQ2Vy
# dGlmaWNhdGlvbiBBdXRob3JpdHkwHhcNMTYwMTEyMDAwMDAwWhcNMzEwMTExMjM1
# OTU5WjB3MQswCQYDVQQGEwJVUzEdMBsGA1UEChMUU3ltYW50ZWMgQ29ycG9yYXRp
# b24xHzAdBgNVBAsTFlN5bWFudGVjIFRydXN0IE5ldHdvcmsxKDAmBgNVBAMTH1N5
# bWFudGVjIFNIQTI1NiBUaW1lU3RhbXBpbmcgQ0EwggEiMA0GCSqGSIb3DQEBAQUA
# A4IBDwAwggEKAoIBAQC7WZ1ZVU+djHJdGoGi61XzsAGtPHGsMo8Fa4aaJwAyl2pN
# yWQUSym7wtkpuS7sY7Phzz8LVpD4Yht+66YH4t5/Xm1AONSRBudBfHkcy8utG7/Y
# lZHz8O5s+K2WOS5/wSe4eDnFhKXt7a+Hjs6Nx23q0pi1Oh8eOZ3D9Jqo9IThxNF8
# ccYGKbQ/5IMNJsN7CD5N+Qq3M0n/yjvU9bKbS+GImRr1wOkzFNbfx4Dbke7+vJJX
# cnf0zajM/gn1kze+lYhqxdz0sUvUzugJkV+1hHk1inisGTKPI8EyQRtZDqk+scz5
# 1ivvt9jk1R1tETqS9pPJnONI7rtTDtQ2l4Z4xaE3AgMBAAGjggF3MIIBczAOBgNV
# HQ8BAf8EBAMCAQYwEgYDVR0TAQH/BAgwBgEB/wIBADBmBgNVHSAEXzBdMFsGC2CG
# SAGG+EUBBxcDMEwwIwYIKwYBBQUHAgEWF2h0dHBzOi8vZC5zeW1jYi5jb20vY3Bz
# MCUGCCsGAQUFBwICMBkaF2h0dHBzOi8vZC5zeW1jYi5jb20vcnBhMC4GCCsGAQUF
# BwEBBCIwIDAeBggrBgEFBQcwAYYSaHR0cDovL3Muc3ltY2QuY29tMDYGA1UdHwQv
# MC0wK6ApoCeGJWh0dHA6Ly9zLnN5bWNiLmNvbS91bml2ZXJzYWwtcm9vdC5jcmww
# EwYDVR0lBAwwCgYIKwYBBQUHAwgwKAYDVR0RBCEwH6QdMBsxGTAXBgNVBAMTEFRp
# bWVTdGFtcC0yMDQ4LTMwHQYDVR0OBBYEFK9j1sqjToVy4Ke8QfMpojh/gHViMB8G
# A1UdIwQYMBaAFLZ3+mlIR59TEtXC6gcydgfRlwcZMA0GCSqGSIb3DQEBCwUAA4IB
# AQB16rAt1TQZXDJF/g7h1E+meMFv1+rd3E/zociBiPenjxXmQCmt5l30otlWZIRx
# MCrdHmEXZiBWBpgZjV1x8viXvAn9HJFHyeLojQP7zJAv1gpsTjPs1rSTyEyQY0g5
# QCHE3dZuiZg8tZiX6KkGtwnJj1NXQZAv4R5NTtzKEHhsQm7wtsX4YVxS9U72a433
# Snq+8839A9fZ9gOoD+NT9wp17MZ1LqpmhQSZt/gGV+HGDvbor9rsmxgfqrnjOgC/
# zoqUywHbnsc4uw9Sq9HjlANgCk2g/idtFDL8P5dA4b+ZidvkORS92uTTw+orWrOV
# WFUEfcea7CMDjYUq0v+uqWGBMIIFSzCCBDOgAwIBAgIQe9Tlr7rMBz+hASMEIkFN
# EjANBgkqhkiG9w0BAQsFADB3MQswCQYDVQQGEwJVUzEdMBsGA1UEChMUU3ltYW50
# ZWMgQ29ycG9yYXRpb24xHzAdBgNVBAsTFlN5bWFudGVjIFRydXN0IE5ldHdvcmsx
# KDAmBgNVBAMTH1N5bWFudGVjIFNIQTI1NiBUaW1lU3RhbXBpbmcgQ0EwHhcNMTcx
# MjIzMDAwMDAwWhcNMjkwMzIyMjM1OTU5WjCBgDELMAkGA1UEBhMCVVMxHTAbBgNV
# BAoTFFN5bWFudGVjIENvcnBvcmF0aW9uMR8wHQYDVQQLExZTeW1hbnRlYyBUcnVz
# dCBOZXR3b3JrMTEwLwYDVQQDEyhTeW1hbnRlYyBTSEEyNTYgVGltZVN0YW1waW5n
# IFNpZ25lciAtIEczMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEArw6K
# qvjcv2l7VBdxRwm9jTyB+HQVd2eQnP3eTgKeS3b25TY+ZdUkIG0w+d0dg+k/J0oz
# Tm0WiuSNQI0iqr6nCxvSB7Y8tRokKPgbclE9yAmIJgg6+fpDI3VHcAyzX1uPCB1y
# SFdlTa8CPED39N0yOJM/5Sym81kjy4DeE035EMmqChhsVWFX0fECLMS1q/JsI9Kf
# DQ8ZbK2FYmn9ToXBilIxq1vYyXRS41dsIr9Vf2/KBqs/SrcidmXs7DbylpWBJiz9
# u5iqATjTryVAmwlT8ClXhVhe6oVIQSGH5d600yaye0BTWHmOUjEGTZQDRcTOPAPs
# twDyOiLFtG/l77CKmwIDAQABo4IBxzCCAcMwDAYDVR0TAQH/BAIwADBmBgNVHSAE
# XzBdMFsGC2CGSAGG+EUBBxcDMEwwIwYIKwYBBQUHAgEWF2h0dHBzOi8vZC5zeW1j
# Yi5jb20vY3BzMCUGCCsGAQUFBwICMBkaF2h0dHBzOi8vZC5zeW1jYi5jb20vcnBh
# MEAGA1UdHwQ5MDcwNaAzoDGGL2h0dHA6Ly90cy1jcmwud3Muc3ltYW50ZWMuY29t
# L3NoYTI1Ni10c3MtY2EuY3JsMBYGA1UdJQEB/wQMMAoGCCsGAQUFBwMIMA4GA1Ud
# DwEB/wQEAwIHgDB3BggrBgEFBQcBAQRrMGkwKgYIKwYBBQUHMAGGHmh0dHA6Ly90
# cy1vY3NwLndzLnN5bWFudGVjLmNvbTA7BggrBgEFBQcwAoYvaHR0cDovL3RzLWFp
# YS53cy5zeW1hbnRlYy5jb20vc2hhMjU2LXRzcy1jYS5jZXIwKAYDVR0RBCEwH6Qd
# MBsxGTAXBgNVBAMTEFRpbWVTdGFtcC0yMDQ4LTYwHQYDVR0OBBYEFKUTAamfhcwb
# bhYeXzsxqnk2AHsdMB8GA1UdIwQYMBaAFK9j1sqjToVy4Ke8QfMpojh/gHViMA0G
# CSqGSIb3DQEBCwUAA4IBAQBGnq/wuKJfoplIz6gnSyHNsrmmcnBjL+NVKXs5Rk7n
# fmUGWIu8V4qSDQjYELo2JPoKe/s702K/SpQV5oLbilRt/yj+Z89xP+YzCdmiWRD0
# Hkr+Zcze1GvjUil1AEorpczLm+ipTfe0F1mSQcO3P4bm9sB/RDxGXBda46Q71Wkm
# 1SF94YBnfmKst04uFZrlnCOvWxHqcalB+Q15OKmhDc+0sdo+mnrHIsV0zd9HCYbE
# /JElshuW6YUI6N3qdGBuYKVWeg3IRFjc5vlIFJ7lv94AvXexmBRyFCTfxxEsHwA/
# w0sUxmcczB4Go5BfXFSLPuMzW4IPxbeGAk5xn+lmRT92MYICWjCCAlYCAQEwgYsw
# dzELMAkGA1UEBhMCVVMxHTAbBgNVBAoTFFN5bWFudGVjIENvcnBvcmF0aW9uMR8w
# HQYDVQQLExZTeW1hbnRlYyBUcnVzdCBOZXR3b3JrMSgwJgYDVQQDEx9TeW1hbnRl
# YyBTSEEyNTYgVGltZVN0YW1waW5nIENBAhB71OWvuswHP6EBIwQiQU0SMAsGCWCG
# SAFlAwQCAaCBpDAaBgkqhkiG9w0BCQMxDQYLKoZIhvcNAQkQAQQwHAYJKoZIhvcN
# AQkFMQ8XDTIwMDMyMzE3MzcyOVowLwYJKoZIhvcNAQkEMSIEIOHmXlrSy7H2u+4v
# /ukyg00Dgs14cXZJVExWXTT1tIE0MDcGCyqGSIb3DQEJEAIvMSgwJjAkMCIEIMR0
# znYAfQI5Tg2l5N58FMaA+eKCATz+9lPvXbcf32H4MAsGCSqGSIb3DQEBAQSCAQAc
# miJ5PXRjb3u8y84cMSbylMTy4OiFojf80osPoPeTPQnnBfzNwnNG+AjljnQcu87k
# Lz15Qbe674S2PljXo3hlDc+7Rh+TJw/HcE2OMxf29hB9BOk3fpEkjexKudOckTik
# sBSDH3wymorCIef92LWz7y0FT0mdfx7axgAQk64PtoHOV143eUWJUMx/xTSOYJYh
# f5mH+Xze3nF9tZ+ec3ccthzzooNngjshSelI7Gx3iqmDxPaLjwwCGJEgZumHz9sK
# axhMgGZUfcqiOnBRAcozwMOyGeC1V+GxukT9+ZhO2sRGdYrWrdN0Gfw+d2D/CBQo
# br9yMKoL8jDopnY4FlpB
# SIG # End signature block
