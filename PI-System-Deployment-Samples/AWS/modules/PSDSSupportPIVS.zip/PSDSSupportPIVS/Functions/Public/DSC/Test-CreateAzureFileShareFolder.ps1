<#
.SYNOPSIS
    This function tests for an Azure file share folder using the Azure REST API.
.DESCRIPTION
    This function tests for the existence of a folder on an Azure File Share. It runs under the presumption that a virtual machine has a Managed Service Account
    VM extension installed and that said account has sufficient rights to the target storage account.
.EXAMPLE
    This example show the test for an Azure File Share's existence with Verbose switched on to show the returning output. The output object is a boolean.
    Test-CreateAzureFileShareFolder -subscriptionId $subscriptionId -storageResourceGroup $fileShareStorageResourceGroup -storageAccount $fileShareStorageAccount -storageShare $fileShareName -rootFolderName $fileShareFolder -Verbose -Debug
        VERBOSE: Getting Azure VM Managed Service identity (MSI) Bearer Token.
        VERBOSE: GET http://localhost:50342/oauth2/token?resource=https:%2F%2Fmanagement.azure.com%2F with 0-byte payload
        VERBOSE: received 1335-byte response of content type application/json
        VERBOSE: Getting Storage Key for storage account where folder will be created.
        VERBOSE: POST https://management.azure.com/subscriptions/28fb33dd-25f0-49a0-926f-72236b87290b/resourceGroups/test42-hostedpi-test-rg/providers/Microsoft.Storage/storageAccounts/tststdjg4jfwskst/listKeys/?api-version=2017-10-01 with 0-byte payload
        VERBOSE: received 288-byte response of content type application/json
        VERBOSE: Generating request header for File Share creation REST call.
        VERBOSE: Executing GET call to check for share.
        VERBOSE: Share URI: https://tststdjg4jfwskst.file.core.windows.net/witness/pian0?restype=directory.
        VERBOSE: GET https://tststdjg4jfwskst.file.core.windows.net/witness/pian0?restype=directory with 0-byte payload
        VERBOSE: received -1-byte response of content type 
        VERBOSE: Share found. Status Code: 200
    True
    This function tests for a folder on an existing Azure File Share. It's intended purpose is to be utilized by the corresponding DSC Configuration resource used by OSIsoft
    Hosted PI deployments. To avoid embedded credentials in scripts, this function leverages the Azure REST API to generate a call to create the Azure File Share.
    As prerequisite, it requires the virtual machine on which it is execute to have a Managed Service Identity (MSI) VM extension installed. Also, the VM's MSI must have
    sufficient permissions to modify the storage account resource. (If using the built in RBAC roles in Azure, you can use the Contributor role, but ensure 
    it is scoped to the target storage account only!). The test makes a GET call for the specified Azure File Share properties as this is a more explicitly call for 
    a specific Azure File Share instance.
#>
function Test-CreateAzureFileShareFolder {
    [CmdletBinding()]
    [OutputType([boolean])]
    param(
        # Subscription ID containing storage account for file share.
        [Parameter(Mandatory = $true)]
        [string]$subscriptionId,

        # Resource Group containing storage account.
        [Parameter(Mandatory = $true)]
        $storageResourceGroup,
        
        # Storage account for file share.
        [Parameter(Mandatory = $true)]
        $storageAccount,

        # Name for File Share
        [Parameter(Mandatory = $true)]
        $storageShare,

        # Name for File Share
        [Parameter(Mandatory = $true)]
        $rootFolderName
    )

    begin {
        Try {
            # Get Bearer Token
            Write-Verbose -Message "Getting Azure VM Managed Service identity (MSI) Bearer Token." -Verbose
            $response = Invoke-WebRequest -Uri http://localhost:50342/oauth2/token -Method GET -UseBasicParsing -Body @{resource = "https://management.azure.com/"} -Headers @{Metadata = "true"}
            $content = $response.Content | ConvertFrom-Json
            $ArmToken = $content.access_token
        }

        Catch {
            Write-Error $_
            throw 'Unable to Azure VM Managed Service identity (MSI) Bearer Token. See error for details.'
        }

    }

    process {
        Try {
            # Get Primary Key from Storage Account
            Write-Verbose -Message "Getting Storage Key for storage account where folder will be created." -Verbose
            $keysResponse = Invoke-WebRequest -Uri "https://management.azure.com/subscriptions/$subscriptionId/resourceGroups/$storageResourceGroup/providers/Microsoft.Storage/storageAccounts/$storageAccount/listKeys/?api-version=2017-10-01" -Method POST -UseBasicParsing -Headers @{Authorization = "Bearer $ARMToken"}
            $keysContent = $keysResponse.Content | ConvertFrom-Json
            $storageKey = $keysContent.keys[0].value  # Account Key
        }

        Catch {
            Write-Error $_
            throw 'Unable to Azure Storage Account Key. See error for details.'
        }


        Try {
            # Build CanonicalizedHeaders for REST API call.
            Write-Verbose -Message "Generating request header for File Share creation REST call." -Verbose
            $headers = @{}
            [DateTime]$UtcTime = (Get-Date ).ToUniversalTime()
            $headerDate = (Get-Date -Date $UtcTime -Format r)
            $headers.Add("x-ms-date", "$headerDate")                 # Request date in UTC and RFC1123 format
            $headers.Add("x-ms-version", "2017-04-17")               # API Version


            # Build Signature String
            # NOTE ORDER MATTERS otherwise request fails and throws exception.
            # If exception is thrown, not that the error indicates the expected format :)
            $signatureString = "GET$([char]10)$([char]10)$([char]10)$([char]10)$([char]10)$([char]10)$([char]10)$([char]10)$([char]10)$([char]10)$([char]10)$([char]10)"
            $signatureString += "x-ms-date:" + $headers["x-ms-date"] + "$([char]10)"
            $signatureString += "x-ms-version:" + $headers["x-ms-version"] + "$([char]10)"


            # Add CanonicalizedResource
            $signatureString += "/" + $storageAccount + "/" + $storageShare + "/" + $rootFolderName + "$([char]10)" + "restype:directory"     # Add CanonicalizedResource


            # Encoding Signature
            $dataToMac = [System.Text.Encoding]::UTF8.GetBytes($signatureString)
            $accountKeyBytes = [System.Convert]::FromBase64String($storageKey)
            $hmac = New-Object System.Security.Cryptography.HMACSHA256((, $accountKeyBytes))
            $signature = [System.Convert]::ToBase64String($hmac.ComputeHash($dataToMac))
            $headers.Add("Authorization", "SharedKey " + $StorageAccount + ":" + $signature)
        }

        Catch {
            Write-Error $_
            throw 'Unable to generate REST API headers. See error for details.'
        }


        Try {
            ## This call checks for the Share. Response 200 = Share exists. Exception = Share not Found
            $newShareFolderUri = "https://" + $storageAccount + ".file.core.windows.net/" + $storageShare + '/' + $rootFolderName + '?restype=directory'
            Write-Verbose -Message "Executing GET call to check for share." -Verbose
            Write-Verbose -Message "Share URI: $($newShareFolderUri)." -Verbose
            $getResponse = Invoke-WebRequest -Uri $newShareFolderUri -Method GET -UseBasicParsing -Headers $headers -ErrorAction Stop

            # If Share is found, expect a 200 response and return $true
            if ($getResponse.StatusCode -eq 200) {
                Write-Verbose -Message "Share found. Status Code: $($getResponse.StatusCode)" -Verbose
                return $true
            }
            else {
                Write-Verbose -Message "Response returned but not 200. Status Code: $($getResponse.StatusCode)" -Verbose
                return $true
            }
        }

        # If Share not found, expect exception of type System.net.WebException. Indicates share's absence and therefore needs creating.
        Catch [System.Net.WebException] {
            $getErr = $Error[0]
            
            Write-Debug -Message "Issue occurred with Web Request. See last error object."

            $shareNotFound = $getErr.ErrorDetails.Message -like "*The specified folder does not exist*"
            if ($shareNotFound) {
                Write-Verbose -Message "Folder $($rootFolderName) was not found. Exception thrown with no response." -Verbose
                return $false
            }
            else {
                Write-Warning -Message "Folder $($rootFolderName) was not found." -Verbose
                Write-Warning -Message "Exception: $($getErr.Exception.Message)" -Verbose
                return $false
            }
        }

        # Catch any other error and output
        Catch {
            Write-Error $_
            throw 'Unable to get Azure File Share. See error for details.'
        }
    }

    end {
    }
}
# SIG # Begin signature block
# MIIbzAYJKoZIhvcNAQcCoIIbvTCCG7kCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAiAC9WKT+KlBVY
# diPKeBZOrsj1Z8NEIZsFRABm/heR/6CCCo4wggUwMIIEGKADAgECAhAECRgbX9W7
# ZnVTQ7VvlVAIMA0GCSqGSIb3DQEBCwUAMGUxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xJDAiBgNV
# BAMTG0RpZ2lDZXJ0IEFzc3VyZWQgSUQgUm9vdCBDQTAeFw0xMzEwMjIxMjAwMDBa
# Fw0yODEwMjIxMjAwMDBaMHIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2Vy
# dCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xMTAvBgNVBAMTKERpZ2lD
# ZXJ0IFNIQTIgQXNzdXJlZCBJRCBDb2RlIFNpZ25pbmcgQ0EwggEiMA0GCSqGSIb3
# DQEBAQUAA4IBDwAwggEKAoIBAQD407Mcfw4Rr2d3B9MLMUkZz9D7RZmxOttE9X/l
# qJ3bMtdx6nadBS63j/qSQ8Cl+YnUNxnXtqrwnIal2CWsDnkoOn7p0WfTxvspJ8fT
# eyOU5JEjlpB3gvmhhCNmElQzUHSxKCa7JGnCwlLyFGeKiUXULaGj6YgsIJWuHEqH
# CN8M9eJNYBi+qsSyrnAxZjNxPqxwoqvOf+l8y5Kh5TsxHM/q8grkV7tKtel05iv+
# bMt+dDk2DZDv5LVOpKnqagqrhPOsZ061xPeM0SAlI+sIZD5SlsHyDxL0xY4PwaLo
# LFH3c7y9hbFig3NBggfkOItqcyDQD2RzPJ6fpjOp/RnfJZPRAgMBAAGjggHNMIIB
# yTASBgNVHRMBAf8ECDAGAQH/AgEAMA4GA1UdDwEB/wQEAwIBhjATBgNVHSUEDDAK
# BggrBgEFBQcDAzB5BggrBgEFBQcBAQRtMGswJAYIKwYBBQUHMAGGGGh0dHA6Ly9v
# Y3NwLmRpZ2ljZXJ0LmNvbTBDBggrBgEFBQcwAoY3aHR0cDovL2NhY2VydHMuZGln
# aWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEUm9vdENBLmNydDCBgQYDVR0fBHow
# eDA6oDigNoY0aHR0cDovL2NybDQuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJl
# ZElEUm9vdENBLmNybDA6oDigNoY0aHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0Rp
# Z2lDZXJ0QXNzdXJlZElEUm9vdENBLmNybDBPBgNVHSAESDBGMDgGCmCGSAGG/WwA
# AgQwKjAoBggrBgEFBQcCARYcaHR0cHM6Ly93d3cuZGlnaWNlcnQuY29tL0NQUzAK
# BghghkgBhv1sAzAdBgNVHQ4EFgQUWsS5eyoKo6XqcQPAYPkt9mV1DlgwHwYDVR0j
# BBgwFoAUReuir/SSy4IxLVGLp6chnfNtyA8wDQYJKoZIhvcNAQELBQADggEBAD7s
# DVoks/Mi0RXILHwlKXaoHV0cLToaxO8wYdd+C2D9wz0PxK+L/e8q3yBVN7Dh9tGS
# dQ9RtG6ljlriXiSBThCk7j9xjmMOE0ut119EefM2FAaK95xGTlz/kLEbBw6RFfu6
# r7VRwo0kriTGxycqoSkoGjpxKAI8LpGjwCUR4pwUR6F6aGivm6dcIFzZcbEMj7uo
# +MUSaJ/PQMtARKUT8OZkDCUIQjKyNookAv4vcn4c10lFluhZHen6dGRrsutmQ9qz
# sIzV6Q3d9gEgzpkxYz0IGhizgZtPxpMQBvwHgfqL2vmCSfdibqFT+hKUGIUukpHq
# aGxEMrJmoecYpJpkUe8wggVWMIIEPqADAgECAhAFTTVZN0yftPMcszD508Q/MA0G
# CSqGSIb3DQEBCwUAMHIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJ
# bmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xMTAvBgNVBAMTKERpZ2lDZXJ0
# IFNIQTIgQXNzdXJlZCBJRCBDb2RlIFNpZ25pbmcgQ0EwHhcNMTkwNjE3MDAwMDAw
# WhcNMjAwNzAxMTIwMDAwWjCBkjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRQw
# EgYDVQQHEwtTYW4gTGVhbmRybzEVMBMGA1UEChMMT1NJc29mdCwgTExDMQwwCgYD
# VQQLEwNEZXYxFTATBgNVBAMTDE9TSXNvZnQsIExMQzEkMCIGCSqGSIb3DQEJARYV
# c21hbmFnZXJzQG9zaXNvZnQuY29tMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIB
# CgKCAQEAqbP+VTz8qtsq4SWhF7LsXqeDGyUwtDpf0vlSg+aQh2fOqJhW2uiPa1GO
# M5+xbr+RhTTWzJX2vEwqSIzN43ktTdgcVT9Bf5W2md+RCYE1D17jGlj5sCFTS4eX
# Htm+lFoQF0donavbA+7+ggd577FdgOnjuYxEpZe2lbUyWcKOHrLQr6Mk/bKjcYSY
# B/ipNK4hvXKTLEsN7k5kyzRkq77PaqbVAQRgnQiv/Lav5xWXuOn7M94TNX4+1Mk8
# 74nuny62KLcMRtjPCc2aWBpHmhD3wPcUVvTW+lGwEaT0DrCwcZDuG/Igkhqj/8Rf
# HYfnZQtWMnBFAHcuA4jJgmZ7xYMPoQIDAQABo4IBxTCCAcEwHwYDVR0jBBgwFoAU
# WsS5eyoKo6XqcQPAYPkt9mV1DlgwHQYDVR0OBBYEFNcTKM3o/Fjj9J3iOakcmKx6
# CPetMA4GA1UdDwEB/wQEAwIHgDATBgNVHSUEDDAKBggrBgEFBQcDAzB3BgNVHR8E
# cDBuMDWgM6Axhi9odHRwOi8vY3JsMy5kaWdpY2VydC5jb20vc2hhMi1hc3N1cmVk
# LWNzLWcxLmNybDA1oDOgMYYvaHR0cDovL2NybDQuZGlnaWNlcnQuY29tL3NoYTIt
# YXNzdXJlZC1jcy1nMS5jcmwwTAYDVR0gBEUwQzA3BglghkgBhv1sAwEwKjAoBggr
# BgEFBQcCARYcaHR0cHM6Ly93d3cuZGlnaWNlcnQuY29tL0NQUzAIBgZngQwBBAEw
# gYQGCCsGAQUFBwEBBHgwdjAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNl
# cnQuY29tME4GCCsGAQUFBzAChkJodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20v
# RGlnaUNlcnRTSEEyQXNzdXJlZElEQ29kZVNpZ25pbmdDQS5jcnQwDAYDVR0TAQH/
# BAIwADANBgkqhkiG9w0BAQsFAAOCAQEAigLIcsGUWzXlZuVQY8s1UOxYgch5qO1Y
# YEDFF8abzJQ4RiB8rcdoRWjsfpWxtGOS0wkA2CfyuWhjO/XqgmYJ8AUHIKKCy6QE
# 31/I6izI6iDCg8X5lSR6nKsB2BCZCOnGJOEi3r+WDS18PMuW24kaBo1ezx6KQOx4
# N0qSrMJqJRXfPHpl3WpcLs3VA1Gew9ATOQ9IXbt8QCvyMICRJxq4heHXPLE3EpK8
# 2wlBKwX3P4phapmEUOWxB45QOcRJqgahe9qIALbLS+i5lxV+eX/87YuEiyDtGfH+
# dAbq5BqlYz1Fr8UrWeR3KIONPNtkm2IFHNMdpsgmKwC/Xh3nC3b27DGCEJQwghCQ
# AgEBMIGGMHIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAX
# BgNVBAsTEHd3dy5kaWdpY2VydC5jb20xMTAvBgNVBAMTKERpZ2lDZXJ0IFNIQTIg
# QXNzdXJlZCBJRCBDb2RlIFNpZ25pbmcgQ0ECEAVNNVk3TJ+08xyzMPnTxD8wDQYJ
# YIZIAWUDBAIBBQCggZ4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIKPgFoovpQ8W
# ePHzEPHYKZTT/qEfgWR+G0BvR2LXJFL/MDIGCisGAQQBgjcCAQwxJDAioSCAHmh0
# dHA6Ly90ZWNoc3VwcG9ydC5vc2lzb2Z0LmNvbTANBgkqhkiG9w0BAQEFAASCAQA7
# YS4k07UEfBEUtzd8XwZlxReBj/soVK5x8fEqCdkz8A67w/XYT+gmJlgEEaVYn6r/
# Zpxag36nBHD297q2TeQ/UVuO7ph38tICq5Zaeb9xZMJIr+mhQTdz5ZJDKj/XibHV
# /d7q8leFLQ//FqGAaeHxHsuYVDidkRgddXkq1EtyVI1TWNMhg9AnC42zzady4PMJ
# YwIG9c2qBQ2m/CYl0N3Q1zwACOh8eFsmr9+wBmj/JE07V3Ri/K00dLryVXWzwMzJ
# wPk1M/jpTdQL9PqEf9phSrMF4sjVt23JlPBJVamLpu9ZIQVPCcy0I2vQxcb36aPy
# GThzmd2g9i8Ti39Up1BAoYIOPTCCDjkGCisGAQQBgjcDAwExgg4pMIIOJQYJKoZI
# hvcNAQcCoIIOFjCCDhICAQMxDTALBglghkgBZQMEAgEwggEPBgsqhkiG9w0BCRAB
# BKCB/wSB/DCB+QIBAQYLYIZIAYb4RQEHFwMwMTANBglghkgBZQMEAgEFAAQg3GbX
# 59DUPiDTSxounjbg0Id7uZz+8lMuP80hXtbQ06ACFQCiBX+d6h2Ju22PCCGSvmBp
# VvEc/RgPMjAyMDAzMjMxNzM3MzFaMAMCAR6ggYakgYMwgYAxCzAJBgNVBAYTAlVT
# MR0wGwYDVQQKExRTeW1hbnRlYyBDb3Jwb3JhdGlvbjEfMB0GA1UECxMWU3ltYW50
# ZWMgVHJ1c3QgTmV0d29yazExMC8GA1UEAxMoU3ltYW50ZWMgU0hBMjU2IFRpbWVT
# dGFtcGluZyBTaWduZXIgLSBHM6CCCoswggU4MIIEIKADAgECAhB7BbHUSWhRRPfJ
# idKcGZ0SMA0GCSqGSIb3DQEBCwUAMIG9MQswCQYDVQQGEwJVUzEXMBUGA1UEChMO
# VmVyaVNpZ24sIEluYy4xHzAdBgNVBAsTFlZlcmlTaWduIFRydXN0IE5ldHdvcmsx
# OjA4BgNVBAsTMShjKSAyMDA4IFZlcmlTaWduLCBJbmMuIC0gRm9yIGF1dGhvcml6
# ZWQgdXNlIG9ubHkxODA2BgNVBAMTL1ZlcmlTaWduIFVuaXZlcnNhbCBSb290IENl
# cnRpZmljYXRpb24gQXV0aG9yaXR5MB4XDTE2MDExMjAwMDAwMFoXDTMxMDExMTIz
# NTk1OVowdzELMAkGA1UEBhMCVVMxHTAbBgNVBAoTFFN5bWFudGVjIENvcnBvcmF0
# aW9uMR8wHQYDVQQLExZTeW1hbnRlYyBUcnVzdCBOZXR3b3JrMSgwJgYDVQQDEx9T
# eW1hbnRlYyBTSEEyNTYgVGltZVN0YW1waW5nIENBMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAu1mdWVVPnYxyXRqBoutV87ABrTxxrDKPBWuGmicAMpdq
# TclkFEspu8LZKbku7GOz4c8/C1aQ+GIbfuumB+Lef15tQDjUkQbnQXx5HMvLrRu/
# 2JWR8/DubPitljkuf8EnuHg5xYSl7e2vh47Ojcdt6tKYtTofHjmdw/SaqPSE4cTR
# fHHGBim0P+SDDSbDewg+TfkKtzNJ/8o71PWym0vhiJka9cDpMxTW38eA25Hu/ryS
# V3J39M2ozP4J9ZM3vpWIasXc9LFL1M7oCZFftYR5NYp4rBkyjyPBMkEbWQ6pPrHM
# +dYr77fY5NUdbRE6kvaTyZzjSO67Uw7UNpeGeMWhNwIDAQABo4IBdzCCAXMwDgYD
# VR0PAQH/BAQDAgEGMBIGA1UdEwEB/wQIMAYBAf8CAQAwZgYDVR0gBF8wXTBbBgtg
# hkgBhvhFAQcXAzBMMCMGCCsGAQUFBwIBFhdodHRwczovL2Quc3ltY2IuY29tL2Nw
# czAlBggrBgEFBQcCAjAZGhdodHRwczovL2Quc3ltY2IuY29tL3JwYTAuBggrBgEF
# BQcBAQQiMCAwHgYIKwYBBQUHMAGGEmh0dHA6Ly9zLnN5bWNkLmNvbTA2BgNVHR8E
# LzAtMCugKaAnhiVodHRwOi8vcy5zeW1jYi5jb20vdW5pdmVyc2FsLXJvb3QuY3Js
# MBMGA1UdJQQMMAoGCCsGAQUFBwMIMCgGA1UdEQQhMB+kHTAbMRkwFwYDVQQDExBU
# aW1lU3RhbXAtMjA0OC0zMB0GA1UdDgQWBBSvY9bKo06FcuCnvEHzKaI4f4B1YjAf
# BgNVHSMEGDAWgBS2d/ppSEefUxLVwuoHMnYH0ZcHGTANBgkqhkiG9w0BAQsFAAOC
# AQEAdeqwLdU0GVwyRf4O4dRPpnjBb9fq3dxP86HIgYj3p48V5kApreZd9KLZVmSE
# cTAq3R5hF2YgVgaYGY1dcfL4l7wJ/RyRR8ni6I0D+8yQL9YKbE4z7Na0k8hMkGNI
# OUAhxN3WbomYPLWYl+ipBrcJyY9TV0GQL+EeTU7cyhB4bEJu8LbF+GFcUvVO9muN
# 90p6vvPN/QPX2fYDqA/jU/cKdezGdS6qZoUEmbf4Blfhxg726K/a7JsYH6q54zoA
# v86KlMsB257HOLsPUqvR45QDYApNoP4nbRQy/D+XQOG/mYnb5DkUvdrk08PqK1qz
# lVhVBH3HmuwjA42FKtL/rqlhgTCCBUswggQzoAMCAQICEHvU5a+6zAc/oQEjBCJB
# TRIwDQYJKoZIhvcNAQELBQAwdzELMAkGA1UEBhMCVVMxHTAbBgNVBAoTFFN5bWFu
# dGVjIENvcnBvcmF0aW9uMR8wHQYDVQQLExZTeW1hbnRlYyBUcnVzdCBOZXR3b3Jr
# MSgwJgYDVQQDEx9TeW1hbnRlYyBTSEEyNTYgVGltZVN0YW1waW5nIENBMB4XDTE3
# MTIyMzAwMDAwMFoXDTI5MDMyMjIzNTk1OVowgYAxCzAJBgNVBAYTAlVTMR0wGwYD
# VQQKExRTeW1hbnRlYyBDb3Jwb3JhdGlvbjEfMB0GA1UECxMWU3ltYW50ZWMgVHJ1
# c3QgTmV0d29yazExMC8GA1UEAxMoU3ltYW50ZWMgU0hBMjU2IFRpbWVTdGFtcGlu
# ZyBTaWduZXIgLSBHMzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAK8O
# iqr43L9pe1QXcUcJvY08gfh0FXdnkJz93k4Cnkt29uU2PmXVJCBtMPndHYPpPydK
# M05tForkjUCNIqq+pwsb0ge2PLUaJCj4G3JRPcgJiCYIOvn6QyN1R3AMs19bjwgd
# ckhXZU2vAjxA9/TdMjiTP+UspvNZI8uA3hNN+RDJqgoYbFVhV9HxAizEtavybCPS
# nw0PGWythWJp/U6FwYpSMatb2Ml0UuNXbCK/VX9vygarP0q3InZl7Ow28paVgSYs
# /buYqgE4068lQJsJU/ApV4VYXuqFSEEhh+XetNMmsntAU1h5jlIxBk2UA0XEzjwD
# 7LcA8joixbRv5e+wipsCAwEAAaOCAccwggHDMAwGA1UdEwEB/wQCMAAwZgYDVR0g
# BF8wXTBbBgtghkgBhvhFAQcXAzBMMCMGCCsGAQUFBwIBFhdodHRwczovL2Quc3lt
# Y2IuY29tL2NwczAlBggrBgEFBQcCAjAZGhdodHRwczovL2Quc3ltY2IuY29tL3Jw
# YTBABgNVHR8EOTA3MDWgM6Axhi9odHRwOi8vdHMtY3JsLndzLnN5bWFudGVjLmNv
# bS9zaGEyNTYtdHNzLWNhLmNybDAWBgNVHSUBAf8EDDAKBggrBgEFBQcDCDAOBgNV
# HQ8BAf8EBAMCB4AwdwYIKwYBBQUHAQEEazBpMCoGCCsGAQUFBzABhh5odHRwOi8v
# dHMtb2NzcC53cy5zeW1hbnRlYy5jb20wOwYIKwYBBQUHMAKGL2h0dHA6Ly90cy1h
# aWEud3Muc3ltYW50ZWMuY29tL3NoYTI1Ni10c3MtY2EuY2VyMCgGA1UdEQQhMB+k
# HTAbMRkwFwYDVQQDExBUaW1lU3RhbXAtMjA0OC02MB0GA1UdDgQWBBSlEwGpn4XM
# G24WHl87Map5NgB7HTAfBgNVHSMEGDAWgBSvY9bKo06FcuCnvEHzKaI4f4B1YjAN
# BgkqhkiG9w0BAQsFAAOCAQEARp6v8LiiX6KZSM+oJ0shzbK5pnJwYy/jVSl7OUZO
# 535lBliLvFeKkg0I2BC6NiT6Cnv7O9Niv0qUFeaC24pUbf8o/mfPcT/mMwnZolkQ
# 9B5K/mXM3tRr41IpdQBKK6XMy5voqU33tBdZkkHDtz+G5vbAf0Q8RlwXWuOkO9Vp
# JtUhfeGAZ35irLdOLhWa5Zwjr1sR6nGpQfkNeTipoQ3PtLHaPpp6xyLFdM3fRwmG
# xPyRJbIblumFCOjd6nRgbmClVnoNyERY3Ob5SBSe5b/eAL13sZgUchQk38cRLB8A
# P8NLFMZnHMweBqOQX1xUiz7jM1uCD8W3hgJOcZ/pZkU/djGCAlowggJWAgEBMIGL
# MHcxCzAJBgNVBAYTAlVTMR0wGwYDVQQKExRTeW1hbnRlYyBDb3Jwb3JhdGlvbjEf
# MB0GA1UECxMWU3ltYW50ZWMgVHJ1c3QgTmV0d29yazEoMCYGA1UEAxMfU3ltYW50
# ZWMgU0hBMjU2IFRpbWVTdGFtcGluZyBDQQIQe9Tlr7rMBz+hASMEIkFNEjALBglg
# hkgBZQMEAgGggaQwGgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMBwGCSqGSIb3
# DQEJBTEPFw0yMDAzMjMxNzM3MzFaMC8GCSqGSIb3DQEJBDEiBCAy47Uja3wrcL3X
# cc5hoFkxK6hxcZW+0h2f+dzmVG2DhzA3BgsqhkiG9w0BCRACLzEoMCYwJDAiBCDE
# dM52AH0COU4NpeTefBTGgPniggE8/vZT7123H99h+DALBgkqhkiG9w0BAQEEggEA
# IW2ZwQkhWDo+MpPogcocnkIKvC2VKEYKaEiE92LKbW/bwG4WJlAvHCFhyzmyu+4H
# w7AFt5ZkETFNocskz05OLeEjGZA64Xh+6eD+jg/D2FZiMi4z9r/yG3D+xTCGJsmQ
# qXC1vully6zD3nwgOt0/wBUH6BTH4+fGgIHXxxQUq/YUJ9kUNOhn+QccOgXDjeYq
# Kwui8lR6ToUmWiurDYu1TgIZrqzH83AhY0yYcFUOm/Y5f2rwjXAl0AYDLb+OQIr/
# LpWB6dCAqQwfqNAgOOCwVRUiU/NcNSdAuNidoMliRowFxR4xDDSnLwbrmY+dmVbT
# cHhRYU7cZbdejHkmv73EIA==
# SIG # End signature block
