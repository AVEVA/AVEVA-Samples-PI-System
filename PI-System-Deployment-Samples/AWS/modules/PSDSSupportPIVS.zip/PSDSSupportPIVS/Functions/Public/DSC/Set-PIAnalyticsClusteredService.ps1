﻿<#
    .SYNOPSIS
    Creates clustered generic service resource. Tuned for PI Analytics and PI Notifications deployments.
    .DESCRIPTION
    This is a helper function used by HostedPI-DSC module. This function is used in the Set portion of the DSC to configure a clustered service resource.
    .NOTES
    This functions purpose is to go throught the multi step process to add a Generic Service resource to a pre-existing Windows Failover cluster.
    The cluster must already exist prior to executing this function. The function is targeted specifically for PI Analytics and PI Notifications
    deployments for failover configuration. Note that for Azure deployments, the lbIPAddress corresponds to the frontend private IP of an internal
    load balancer which is necessary for Azure networking. For on-prem deployments, this simply needs to be an vacant available IP that the cluster 
    can use to use identify the service resource.
    .EXAMPLE
    This example shows the configuration for a clustered service resource called 'PIAN0-CLSTSVC' for PI Analytics. The service becomes available as a
    clustered resource on IP 10.207.0.188 and by the DNS entry for PIAN0-CLSTSVC.mydomain.int (assuming FQDN is mydomain.int).
    PS C:\> Set-PIAnalyticsClusteredService -clusterResourceName 'PIAN0-CLSTSVC' -lbIPAddress '10.207.0.188' -serviceName PIAnalysisManager -Verbose
        VERBOSE: 1. Create Cluster Group - Add Cluster Group
        VERBOSE: Connecting to cluster on local computer tst-pian-vm0.

        VERBOSE: 2. Generic Service - Add Network Resource.
        VERBOSE: Connecting to cluster on local computer tst-pian-vm0.
        VERBOSE: 3. IP Resource - Add IP Address + Set IPAddress/SubnetMask/ProbePort
        VERBOSE: Connecting to cluster on local computer tst-pian-vm0.
        Name          OwnerNode    State 
        ----          ---------    ----- 
        PIAN0-CLSTSVC tst-pian-vm0 Online

        Name         : PI Analysis Service
        State        : Offline
        OwnerGroup   : PIAN0-CLSTSVC
        ResourceType : Generic Service


        Name         : IP Address_10.207.0.188
        State        : Offline
        OwnerGroup   : PIAN0-CLSTSVC
        ResourceType : IP Address

        VERBOSE: Connecting to cluster on local computer tst-pian-vm0.
        VERBOSE: 4. Network Name - Add Network Name Resource, Set dependency on IP Resource, Set DNS Entry
        VERBOSE: Connecting to cluster on local computer tst-pian-vm0.

        Name         : PIAN0-CLSTSVC
        State        : Offline
        OwnerGroup   : PIAN0-CLSTSVC
        ResourceType : Network Name

        VERBOSE: Connecting to cluster on local computer tst-pian-vm0.
        VERBOSE: Connecting to cluster on local computer tst-pian-vm0.
        VERBOSE: 5. Generic Service - Set Registry entry, Add Dependency on Network Name, Add Service Name + Enable Use Network Name
        VERBOSE: Connecting to cluster on local computer tst-pian-vm0.

        Resource : PI Analysis Service
        Name     : SOFTWARE\PISystem\Analysis Service

        VERBOSE: Connecting to cluster on local computer tst-pian-vm0.
        VERBOSE: Connecting to cluster on local computer tst-pian-vm0.
        VERBOSE: 6. Restarting cluster resources to ensure the service is brought online.
        VERBOSE: Connecting to cluster on local computer tst-pian-vm0.
        VERBOSE: Resource 'IP Address_10.207.0.188' is now in state Offline.

        Name         : IP Address_10.207.0.188
        State        : Offline
        OwnerGroup   : PIAN0-CLSTSVC
        ResourceType : IP Address

        VERBOSE: Connecting to cluster on local computer tst-pian-vm0.
        VERBOSE: Resource 'PIAN0-CLSTSVC' is now in state Offline.

        Name         : PIAN0-CLSTSVC
        State        : Offline
        OwnerGroup   : PIAN0-CLSTSVC
        ResourceType : Network Name

        VERBOSE: Connecting to cluster on local computer tst-pian-vm0.
        VERBOSE: Resource 'PI Analysis Service' is now in state Offline.

        Name         : PI Analysis Service
        State        : Offline
        OwnerGroup   : PIAN0-CLSTSVC
        ResourceType : Generic Service

        VERBOSE: Connecting to cluster on local computer tst-pian-vm0.
        VERBOSE: Resource 'PIAN0-CLSTSVC' is now in state Online.

        Name         : PIAN0-CLSTSVC
        State        : Online
        OwnerGroup   : PIAN0-CLSTSVC
        ResourceType : Network Name

        VERBOSE: Connecting to cluster on local computer tst-pian-vm0.
        VERBOSE: Resource 'IP Address_10.207.0.188' is now in state Online.

        Name         : IP Address_10.207.0.188
        State        : Online
        OwnerGroup   : PIAN0-CLSTSVC
        ResourceType : IP Address

        VERBOSE: Connecting to cluster on local computer tst-pian-vm0.
        VERBOSE: Resource 'PI Analysis Service' is now in state Online.

        Name         : PI Analysis Service
        State        : Online
        OwnerGroup   : PIAN0-CLSTSVC
        ResourceType : Generic Service

        VERBOSE: 7. Cluster resources restarted and online.

#>
function Set-PIAnalyticsClusteredService {
    param(
        # Name used to identify clustered service resource. This appears in DNS, e.g. 'PIAN0-CLSTSVC'.
        [Parameter(Mandatory = $true)]
        [string]$clusterResourceName,

        # IP Address for service resource. For Azure deployments, this corresponds to the internal load balancer private IP address.
        [Parameter(Mandatory = $true)]
        [string]$lbIPAddress,

        # Subnet mask applied to IP resource.
        [Parameter()]
        [string]$subnetMask = '255.255.255.192',

        # Service name of service that will become the clustered resource.
        [Parameter()]
        [ValidateSet('PIAnalysisManager')]
        [string]$serviceName = 'PIAnalysisManager'    
    )
  
    # Registry entry associated with clustered resource for the service.
    [string]$registryCheckpoint = 'SOFTWARE\PISystem\Analysis Service'

    # Aggregate properties for setting Network Resource Name
    [string]$networkResource = $serviceName                 # Use Service name for simplicity
    [string]$ipResource = "IP Address_" + $lbIPAddress      # Concatenate IP Resource Name
    [System.UInt32]$UseNetworkName = 1                      # Cast input to correct type.
  
  
    #region 1. Create Cluster Group - Add Cluster Group
    Try {
        Write-Verbose -Message "1. Create Cluster Group - Add Cluster Group" -Verbose
        Add-ClusterGroup -Name $clusterResourceName -GroupType GenericService -ErrorAction Stop 
    }
    
    Catch [Microsoft.FailoverClusters.PowerShell.ClusterCmdletException] {
        Write-Warning -Message "$_.ErrorDetails.Message"
        Write-Verbose -Message "Resource Group $clusterResourceName already exists." -Verbose
    }
    
    Catch {
        Write-Error $_
    }
    #endregion 1. Create Cluster group
  
  
    #region 2. Generic Service - Add Network Resource.
    Try {
        Write-Verbose -Message "2. Generic Service - Add Network Resource." -Verbose
        Add-ClusterResource -Name $networkResource -ResourceType "Generic Service" -Group $clusterResourceName -ErrorAction Stop 
    }
    Catch [Microsoft.FailoverClusters.PowerShell.ClusterCmdletException] {
        Write-Warning -Message "$_.ErrorDetails.Message"
        Write-Verbose -Message "CLuster role $networkResource already exists." -Verbose
    }
    Catch {
        Write-Error $_
        Continue
    }
    #endregion 2. Generic Service - Add Network Resource.
  
  
    #region 3. IP Resource - Add IP Address + Set IPAddress/SubnetMask/ProbePort
    Try {
        Write-Verbose -Message "3. IP Resource - Add IP Address + Set IPAddress/SubnetMask/ProbePort" -Verbose
        Add-ClusterResource -Name $ipResource -ResourceType "IP Address" -Group $clusterResourceName -ErrorAction Stop
    }    
    Catch [Microsoft.FailoverClusters.PowerShell.ClusterCmdletException] {
        Write-Warning -Message "$_.ErrorDetails.Message"
        Write-Verbose -Message "IP resource $ipResource already exists." -Verbose
    }
    Catch {
        Write-Error $_
        Continue
    }
    
    Try {
        Get-ClusterResource -Name $ipResource -ErrorAction Stop |
            Set-ClusterParameter -Multiple @{"Address" = $lbIPAddress; "SubnetMask" = $subnetMask; 'ProbePort' = 59999 } -ErrorAction Stop
    }
    Catch {
        Write-Error $_
        Continue
    }
    #endregion 3. IP Resource - Add IP Address + Set IPAddress/SubnetMask/ProbePort
  
  
    #region 4. Network Name - Add Network Name Resource, Set dependency on IP Resource, Set DNS Entry
    Try {
        Write-Verbose -Message "4. Network Name - Add Network Name Resource, Set dependency on IP Resource, Set DNS Entry" -Verbose
        Add-ClusterResource -Name $clusterResourceName -ResourceType "Network Name" -Group $clusterResourceName  -ErrorAction Stop
    }
    Catch [Microsoft.FailoverClusters.PowerShell.ClusterCmdletException] {
        Write-Warning -Message "$_.ErrorDetails.Message"
        Write-Verbose -Message "Network resource $clusterResourceName already exists." -Verbose
    }
    
    Try {
        Get-ClusterResource -Name $clusterResourceName -ErrorAction Stop |
            Set-ClusterResourceDependency -Resource $clusterResourceName -Dependency "[$ipResource]" -ErrorAction Stop 
      
        Get-ClusterResource -Name $clusterResourceName -ErrorAction Stop |
            Set-ClusterParameter -Multiple @{"DnsName" = $clusterResourceName; "Name" = $clusterResourceName } -ErrorAction Stop 
    }
    Catch {
        Write-Error $_
        Continue
    }
    #endregion 4. Network Name - Add Network Name Resource, Set dependency on IP Resource, Set DNS Entry
  
  
    #region 5. Generic Service - Set Registry entry, Add Dependency on Network Name, Add Service Name + Enable Use Network Name
    Try {
        Write-Verbose -Message "5. Generic Service - Set Registry entry, Add Dependency on Network Name, Add Service Name + Enable Use Network Name" -Verbose
        Add-ClusterCheckpoint -ResourceName $networkResource -RegistryCheckpoint $registryCheckpoint -ErrorAction Stop 
    }
    Catch [Microsoft.FailoverClusters.PowerShell.ClusterCmdletException] {
        Write-Warning -Message "$_.ErrorDetails.Message"
        Write-Verbose -Message "RegisteryCheckPoint $registryCheckpoint already exists." -Verbose
    }
    Catch {
        Write-Error $_
        Continue
    }
    
    Try {
        Get-ClusterResource -Name $networkResource -ErrorAction Stop |
            Set-ClusterResourceDependency -Resource $networkResource -Dependency "[$clusterResourceName]" -ErrorAction Stop
      
        Get-ClusterResource -Name $networkResource -ErrorAction Stop |
            Set-ClusterParameter -Multiple @{"ServiceName" = $serviceName; "UseNetworkName" = "$UseNetworkName"} -ErrorAction Stop 
      
        ## Ensure all resources are stopped
        Write-Verbose -Message "6. Restarting cluster resources to ensure the service is brought online." -Verbose
        Stop-ClusterResource $ipResource -ErrorAction Stop 
        Stop-ClusterResource $clusterResourceName -ErrorAction Stop 
        Stop-ClusterResource $networkResource -ErrorAction Stop 
      
        ## Start all resources
        Start-ClusterResource $clusterResourceName -ErrorAction Stop 
        Start-ClusterResource $ipResource -ErrorAction Stop 
        Start-ClusterResource $networkResource -ErrorAction Stop
        Write-Verbose -Message "7. Cluster resources restarted and online." -Verbose
    }
    Catch {
        Write-Error $_
    }
    #endregion 5. Generic Service - Set Registry entry, Add Dependency on Network Name, Add Service Name + Enable Use Network Name
}
# SIG # Begin signature block
# MIIbzAYJKoZIhvcNAQcCoIIbvTCCG7kCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDNJOC+DK+2gdT2
# aeH8wff7qjSVuMl9z35Gj0FXhbGw4qCCCo4wggUwMIIEGKADAgECAhAECRgbX9W7
# ZnVTQ7VvlVAIMA0GCSqGSIb3DQEBCwUAMGUxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xJDAiBgNV
# BAMTG0RpZ2lDZXJ0IEFzc3VyZWQgSUQgUm9vdCBDQTAeFw0xMzEwMjIxMjAwMDBa
# Fw0yODEwMjIxMjAwMDBaMHIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2Vy
# dCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xMTAvBgNVBAMTKERpZ2lD
# ZXJ0IFNIQTIgQXNzdXJlZCBJRCBDb2RlIFNpZ25pbmcgQ0EwggEiMA0GCSqGSIb3
# DQEBAQUAA4IBDwAwggEKAoIBAQD407Mcfw4Rr2d3B9MLMUkZz9D7RZmxOttE9X/l
# qJ3bMtdx6nadBS63j/qSQ8Cl+YnUNxnXtqrwnIal2CWsDnkoOn7p0WfTxvspJ8fT
# eyOU5JEjlpB3gvmhhCNmElQzUHSxKCa7JGnCwlLyFGeKiUXULaGj6YgsIJWuHEqH
# CN8M9eJNYBi+qsSyrnAxZjNxPqxwoqvOf+l8y5Kh5TsxHM/q8grkV7tKtel05iv+
# bMt+dDk2DZDv5LVOpKnqagqrhPOsZ061xPeM0SAlI+sIZD5SlsHyDxL0xY4PwaLo
# LFH3c7y9hbFig3NBggfkOItqcyDQD2RzPJ6fpjOp/RnfJZPRAgMBAAGjggHNMIIB
# yTASBgNVHRMBAf8ECDAGAQH/AgEAMA4GA1UdDwEB/wQEAwIBhjATBgNVHSUEDDAK
# BggrBgEFBQcDAzB5BggrBgEFBQcBAQRtMGswJAYIKwYBBQUHMAGGGGh0dHA6Ly9v
# Y3NwLmRpZ2ljZXJ0LmNvbTBDBggrBgEFBQcwAoY3aHR0cDovL2NhY2VydHMuZGln
# aWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEUm9vdENBLmNydDCBgQYDVR0fBHow
# eDA6oDigNoY0aHR0cDovL2NybDQuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJl
# ZElEUm9vdENBLmNybDA6oDigNoY0aHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0Rp
# Z2lDZXJ0QXNzdXJlZElEUm9vdENBLmNybDBPBgNVHSAESDBGMDgGCmCGSAGG/WwA
# AgQwKjAoBggrBgEFBQcCARYcaHR0cHM6Ly93d3cuZGlnaWNlcnQuY29tL0NQUzAK
# BghghkgBhv1sAzAdBgNVHQ4EFgQUWsS5eyoKo6XqcQPAYPkt9mV1DlgwHwYDVR0j
# BBgwFoAUReuir/SSy4IxLVGLp6chnfNtyA8wDQYJKoZIhvcNAQELBQADggEBAD7s
# DVoks/Mi0RXILHwlKXaoHV0cLToaxO8wYdd+C2D9wz0PxK+L/e8q3yBVN7Dh9tGS
# dQ9RtG6ljlriXiSBThCk7j9xjmMOE0ut119EefM2FAaK95xGTlz/kLEbBw6RFfu6
# r7VRwo0kriTGxycqoSkoGjpxKAI8LpGjwCUR4pwUR6F6aGivm6dcIFzZcbEMj7uo
# +MUSaJ/PQMtARKUT8OZkDCUIQjKyNookAv4vcn4c10lFluhZHen6dGRrsutmQ9qz
# sIzV6Q3d9gEgzpkxYz0IGhizgZtPxpMQBvwHgfqL2vmCSfdibqFT+hKUGIUukpHq
# aGxEMrJmoecYpJpkUe8wggVWMIIEPqADAgECAhAFTTVZN0yftPMcszD508Q/MA0G
# CSqGSIb3DQEBCwUAMHIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJ
# bmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xMTAvBgNVBAMTKERpZ2lDZXJ0
# IFNIQTIgQXNzdXJlZCBJRCBDb2RlIFNpZ25pbmcgQ0EwHhcNMTkwNjE3MDAwMDAw
# WhcNMjAwNzAxMTIwMDAwWjCBkjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRQw
# EgYDVQQHEwtTYW4gTGVhbmRybzEVMBMGA1UEChMMT1NJc29mdCwgTExDMQwwCgYD
# VQQLEwNEZXYxFTATBgNVBAMTDE9TSXNvZnQsIExMQzEkMCIGCSqGSIb3DQEJARYV
# c21hbmFnZXJzQG9zaXNvZnQuY29tMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIB
# CgKCAQEAqbP+VTz8qtsq4SWhF7LsXqeDGyUwtDpf0vlSg+aQh2fOqJhW2uiPa1GO
# M5+xbr+RhTTWzJX2vEwqSIzN43ktTdgcVT9Bf5W2md+RCYE1D17jGlj5sCFTS4eX
# Htm+lFoQF0donavbA+7+ggd577FdgOnjuYxEpZe2lbUyWcKOHrLQr6Mk/bKjcYSY
# B/ipNK4hvXKTLEsN7k5kyzRkq77PaqbVAQRgnQiv/Lav5xWXuOn7M94TNX4+1Mk8
# 74nuny62KLcMRtjPCc2aWBpHmhD3wPcUVvTW+lGwEaT0DrCwcZDuG/Igkhqj/8Rf
# HYfnZQtWMnBFAHcuA4jJgmZ7xYMPoQIDAQABo4IBxTCCAcEwHwYDVR0jBBgwFoAU
# WsS5eyoKo6XqcQPAYPkt9mV1DlgwHQYDVR0OBBYEFNcTKM3o/Fjj9J3iOakcmKx6
# CPetMA4GA1UdDwEB/wQEAwIHgDATBgNVHSUEDDAKBggrBgEFBQcDAzB3BgNVHR8E
# cDBuMDWgM6Axhi9odHRwOi8vY3JsMy5kaWdpY2VydC5jb20vc2hhMi1hc3N1cmVk
# LWNzLWcxLmNybDA1oDOgMYYvaHR0cDovL2NybDQuZGlnaWNlcnQuY29tL3NoYTIt
# YXNzdXJlZC1jcy1nMS5jcmwwTAYDVR0gBEUwQzA3BglghkgBhv1sAwEwKjAoBggr
# BgEFBQcCARYcaHR0cHM6Ly93d3cuZGlnaWNlcnQuY29tL0NQUzAIBgZngQwBBAEw
# gYQGCCsGAQUFBwEBBHgwdjAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNl
# cnQuY29tME4GCCsGAQUFBzAChkJodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20v
# RGlnaUNlcnRTSEEyQXNzdXJlZElEQ29kZVNpZ25pbmdDQS5jcnQwDAYDVR0TAQH/
# BAIwADANBgkqhkiG9w0BAQsFAAOCAQEAigLIcsGUWzXlZuVQY8s1UOxYgch5qO1Y
# YEDFF8abzJQ4RiB8rcdoRWjsfpWxtGOS0wkA2CfyuWhjO/XqgmYJ8AUHIKKCy6QE
# 31/I6izI6iDCg8X5lSR6nKsB2BCZCOnGJOEi3r+WDS18PMuW24kaBo1ezx6KQOx4
# N0qSrMJqJRXfPHpl3WpcLs3VA1Gew9ATOQ9IXbt8QCvyMICRJxq4heHXPLE3EpK8
# 2wlBKwX3P4phapmEUOWxB45QOcRJqgahe9qIALbLS+i5lxV+eX/87YuEiyDtGfH+
# dAbq5BqlYz1Fr8UrWeR3KIONPNtkm2IFHNMdpsgmKwC/Xh3nC3b27DGCEJQwghCQ
# AgEBMIGGMHIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAX
# BgNVBAsTEHd3dy5kaWdpY2VydC5jb20xMTAvBgNVBAMTKERpZ2lDZXJ0IFNIQTIg
# QXNzdXJlZCBJRCBDb2RlIFNpZ25pbmcgQ0ECEAVNNVk3TJ+08xyzMPnTxD8wDQYJ
# YIZIAWUDBAIBBQCggZ4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIHUWS4EShLbH
# tJE7yl8g7BMwp1c4anGyEHqpfdGu7r0YMDIGCisGAQQBgjcCAQwxJDAioSCAHmh0
# dHA6Ly90ZWNoc3VwcG9ydC5vc2lzb2Z0LmNvbTANBgkqhkiG9w0BAQEFAASCAQB3
# 0rQx8KiP+mkmyDkaV2thsAXmqU5COhX1PWlnJfObG2Mdvph4VwwNrdKZfmOVwDIO
# XrxuFMSjbnjT//Any/eDDM9VmPttSLG+qJ8RUcw5t9zvok+0hCRTvtA/ty1ILd2b
# cU7htfPApfsq/Ucin04m/z2KVAhmHWbTw9d2acVlKo9g9M2Rpa8oWgOpjiTLKe9f
# cYNW5XB0cdFc52VFYhMCrOoMbUTPGQYuVfM669W/eJk6Hca6+mZIwfuWIfarbV7Q
# TAY71cLt/ciXDnIF4mAhdFaQBSUpEYYHclSTO5hQBxXPJ3eVH7EDQHdR+rZkkT5H
# k7S3S4BwgCuXA6mI/TpsoYIOPTCCDjkGCisGAQQBgjcDAwExgg4pMIIOJQYJKoZI
# hvcNAQcCoIIOFjCCDhICAQMxDTALBglghkgBZQMEAgEwggEPBgsqhkiG9w0BCRAB
# BKCB/wSB/DCB+QIBAQYLYIZIAYb4RQEHFwMwMTANBglghkgBZQMEAgEFAAQgfn2d
# Y0Okit0A+tahiwDE5w92fx7pY3H5HEjnAwr2W/ICFQCbBCMc88mLlHR1W5B8fw9a
# w0wQehgPMjAyMDAzMjMxNzM3MjNaMAMCAR6ggYakgYMwgYAxCzAJBgNVBAYTAlVT
# MR0wGwYDVQQKExRTeW1hbnRlYyBDb3Jwb3JhdGlvbjEfMB0GA1UECxMWU3ltYW50
# ZWMgVHJ1c3QgTmV0d29yazExMC8GA1UEAxMoU3ltYW50ZWMgU0hBMjU2IFRpbWVT
# dGFtcGluZyBTaWduZXIgLSBHM6CCCoswggU4MIIEIKADAgECAhB7BbHUSWhRRPfJ
# idKcGZ0SMA0GCSqGSIb3DQEBCwUAMIG9MQswCQYDVQQGEwJVUzEXMBUGA1UEChMO
# VmVyaVNpZ24sIEluYy4xHzAdBgNVBAsTFlZlcmlTaWduIFRydXN0IE5ldHdvcmsx
# OjA4BgNVBAsTMShjKSAyMDA4IFZlcmlTaWduLCBJbmMuIC0gRm9yIGF1dGhvcml6
# ZWQgdXNlIG9ubHkxODA2BgNVBAMTL1ZlcmlTaWduIFVuaXZlcnNhbCBSb290IENl
# cnRpZmljYXRpb24gQXV0aG9yaXR5MB4XDTE2MDExMjAwMDAwMFoXDTMxMDExMTIz
# NTk1OVowdzELMAkGA1UEBhMCVVMxHTAbBgNVBAoTFFN5bWFudGVjIENvcnBvcmF0
# aW9uMR8wHQYDVQQLExZTeW1hbnRlYyBUcnVzdCBOZXR3b3JrMSgwJgYDVQQDEx9T
# eW1hbnRlYyBTSEEyNTYgVGltZVN0YW1waW5nIENBMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAu1mdWVVPnYxyXRqBoutV87ABrTxxrDKPBWuGmicAMpdq
# TclkFEspu8LZKbku7GOz4c8/C1aQ+GIbfuumB+Lef15tQDjUkQbnQXx5HMvLrRu/
# 2JWR8/DubPitljkuf8EnuHg5xYSl7e2vh47Ojcdt6tKYtTofHjmdw/SaqPSE4cTR
# fHHGBim0P+SDDSbDewg+TfkKtzNJ/8o71PWym0vhiJka9cDpMxTW38eA25Hu/ryS
# V3J39M2ozP4J9ZM3vpWIasXc9LFL1M7oCZFftYR5NYp4rBkyjyPBMkEbWQ6pPrHM
# +dYr77fY5NUdbRE6kvaTyZzjSO67Uw7UNpeGeMWhNwIDAQABo4IBdzCCAXMwDgYD
# VR0PAQH/BAQDAgEGMBIGA1UdEwEB/wQIMAYBAf8CAQAwZgYDVR0gBF8wXTBbBgtg
# hkgBhvhFAQcXAzBMMCMGCCsGAQUFBwIBFhdodHRwczovL2Quc3ltY2IuY29tL2Nw
# czAlBggrBgEFBQcCAjAZGhdodHRwczovL2Quc3ltY2IuY29tL3JwYTAuBggrBgEF
# BQcBAQQiMCAwHgYIKwYBBQUHMAGGEmh0dHA6Ly9zLnN5bWNkLmNvbTA2BgNVHR8E
# LzAtMCugKaAnhiVodHRwOi8vcy5zeW1jYi5jb20vdW5pdmVyc2FsLXJvb3QuY3Js
# MBMGA1UdJQQMMAoGCCsGAQUFBwMIMCgGA1UdEQQhMB+kHTAbMRkwFwYDVQQDExBU
# aW1lU3RhbXAtMjA0OC0zMB0GA1UdDgQWBBSvY9bKo06FcuCnvEHzKaI4f4B1YjAf
# BgNVHSMEGDAWgBS2d/ppSEefUxLVwuoHMnYH0ZcHGTANBgkqhkiG9w0BAQsFAAOC
# AQEAdeqwLdU0GVwyRf4O4dRPpnjBb9fq3dxP86HIgYj3p48V5kApreZd9KLZVmSE
# cTAq3R5hF2YgVgaYGY1dcfL4l7wJ/RyRR8ni6I0D+8yQL9YKbE4z7Na0k8hMkGNI
# OUAhxN3WbomYPLWYl+ipBrcJyY9TV0GQL+EeTU7cyhB4bEJu8LbF+GFcUvVO9muN
# 90p6vvPN/QPX2fYDqA/jU/cKdezGdS6qZoUEmbf4Blfhxg726K/a7JsYH6q54zoA
# v86KlMsB257HOLsPUqvR45QDYApNoP4nbRQy/D+XQOG/mYnb5DkUvdrk08PqK1qz
# lVhVBH3HmuwjA42FKtL/rqlhgTCCBUswggQzoAMCAQICEHvU5a+6zAc/oQEjBCJB
# TRIwDQYJKoZIhvcNAQELBQAwdzELMAkGA1UEBhMCVVMxHTAbBgNVBAoTFFN5bWFu
# dGVjIENvcnBvcmF0aW9uMR8wHQYDVQQLExZTeW1hbnRlYyBUcnVzdCBOZXR3b3Jr
# MSgwJgYDVQQDEx9TeW1hbnRlYyBTSEEyNTYgVGltZVN0YW1waW5nIENBMB4XDTE3
# MTIyMzAwMDAwMFoXDTI5MDMyMjIzNTk1OVowgYAxCzAJBgNVBAYTAlVTMR0wGwYD
# VQQKExRTeW1hbnRlYyBDb3Jwb3JhdGlvbjEfMB0GA1UECxMWU3ltYW50ZWMgVHJ1
# c3QgTmV0d29yazExMC8GA1UEAxMoU3ltYW50ZWMgU0hBMjU2IFRpbWVTdGFtcGlu
# ZyBTaWduZXIgLSBHMzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAK8O
# iqr43L9pe1QXcUcJvY08gfh0FXdnkJz93k4Cnkt29uU2PmXVJCBtMPndHYPpPydK
# M05tForkjUCNIqq+pwsb0ge2PLUaJCj4G3JRPcgJiCYIOvn6QyN1R3AMs19bjwgd
# ckhXZU2vAjxA9/TdMjiTP+UspvNZI8uA3hNN+RDJqgoYbFVhV9HxAizEtavybCPS
# nw0PGWythWJp/U6FwYpSMatb2Ml0UuNXbCK/VX9vygarP0q3InZl7Ow28paVgSYs
# /buYqgE4068lQJsJU/ApV4VYXuqFSEEhh+XetNMmsntAU1h5jlIxBk2UA0XEzjwD
# 7LcA8joixbRv5e+wipsCAwEAAaOCAccwggHDMAwGA1UdEwEB/wQCMAAwZgYDVR0g
# BF8wXTBbBgtghkgBhvhFAQcXAzBMMCMGCCsGAQUFBwIBFhdodHRwczovL2Quc3lt
# Y2IuY29tL2NwczAlBggrBgEFBQcCAjAZGhdodHRwczovL2Quc3ltY2IuY29tL3Jw
# YTBABgNVHR8EOTA3MDWgM6Axhi9odHRwOi8vdHMtY3JsLndzLnN5bWFudGVjLmNv
# bS9zaGEyNTYtdHNzLWNhLmNybDAWBgNVHSUBAf8EDDAKBggrBgEFBQcDCDAOBgNV
# HQ8BAf8EBAMCB4AwdwYIKwYBBQUHAQEEazBpMCoGCCsGAQUFBzABhh5odHRwOi8v
# dHMtb2NzcC53cy5zeW1hbnRlYy5jb20wOwYIKwYBBQUHMAKGL2h0dHA6Ly90cy1h
# aWEud3Muc3ltYW50ZWMuY29tL3NoYTI1Ni10c3MtY2EuY2VyMCgGA1UdEQQhMB+k
# HTAbMRkwFwYDVQQDExBUaW1lU3RhbXAtMjA0OC02MB0GA1UdDgQWBBSlEwGpn4XM
# G24WHl87Map5NgB7HTAfBgNVHSMEGDAWgBSvY9bKo06FcuCnvEHzKaI4f4B1YjAN
# BgkqhkiG9w0BAQsFAAOCAQEARp6v8LiiX6KZSM+oJ0shzbK5pnJwYy/jVSl7OUZO
# 535lBliLvFeKkg0I2BC6NiT6Cnv7O9Niv0qUFeaC24pUbf8o/mfPcT/mMwnZolkQ
# 9B5K/mXM3tRr41IpdQBKK6XMy5voqU33tBdZkkHDtz+G5vbAf0Q8RlwXWuOkO9Vp
# JtUhfeGAZ35irLdOLhWa5Zwjr1sR6nGpQfkNeTipoQ3PtLHaPpp6xyLFdM3fRwmG
# xPyRJbIblumFCOjd6nRgbmClVnoNyERY3Ob5SBSe5b/eAL13sZgUchQk38cRLB8A
# P8NLFMZnHMweBqOQX1xUiz7jM1uCD8W3hgJOcZ/pZkU/djGCAlowggJWAgEBMIGL
# MHcxCzAJBgNVBAYTAlVTMR0wGwYDVQQKExRTeW1hbnRlYyBDb3Jwb3JhdGlvbjEf
# MB0GA1UECxMWU3ltYW50ZWMgVHJ1c3QgTmV0d29yazEoMCYGA1UEAxMfU3ltYW50
# ZWMgU0hBMjU2IFRpbWVTdGFtcGluZyBDQQIQe9Tlr7rMBz+hASMEIkFNEjALBglg
# hkgBZQMEAgGggaQwGgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMBwGCSqGSIb3
# DQEJBTEPFw0yMDAzMjMxNzM3MjNaMC8GCSqGSIb3DQEJBDEiBCCEIt4EW0B1tj9B
# rAvNhRF5PIhY4+7WpjKJtuDmTq4FEzA3BgsqhkiG9w0BCRACLzEoMCYwJDAiBCDE
# dM52AH0COU4NpeTefBTGgPniggE8/vZT7123H99h+DALBgkqhkiG9w0BAQEEggEA
# h1/zkPUSjAt850sOIUej+kFPUx0MUnhiZMmDYd4A77fnOzHX6EfDnK7I0OozRxFr
# r9dcIoj25LJabkcoK9jW8HohQhS0VrC0MwVo+Gs2zRN/M7B1Og5rA+oxDtHJbZu5
# C6ogwfEjPMGEYFTU31ScBUOf8lm0ZkPAtvigJ8tFzSp9lGFEqEWS3FYlXP+nvv/d
# 9rIamXyi5irFY8lMbBWacZFSB+hN6kaELYom9AR80000B2dkoCfPDN2JFkc9jrub
# 9u9vO31JM3UQpW94Yyx2sKQBJRkL88Be+XRcSfk2ol+bdS9nPcRciq0wH7dJr5T+
# yCvp/aDgvgGPA2ZhsHzWWA==
# SIG # End signature block
