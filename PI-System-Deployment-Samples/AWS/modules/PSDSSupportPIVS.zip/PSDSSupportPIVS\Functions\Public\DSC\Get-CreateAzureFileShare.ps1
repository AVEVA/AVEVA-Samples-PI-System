<#
.SYNOPSIS
    This function tests for an Azure file share using the Azure REST API.
.DESCRIPTION
    This function tests for the existence of an Azure File Share. It runs under the presumption that a virtual machine has a Managed Service Account
    VM extension installed and that said account has sufficient rights to the target storage account.
.EXAMPLE
    This example show the test for an Azure File Share's existence with Verbose switched on to show the returning output. The output object is a boolean.
    Get-CreateAzureFileShare -subscriptionId $subscriptionId -storageResourceGroup $storageResoruceGroup -storageAccount $storageAccount -storageShare $storageShare -Verbose
        VERBOSE: Getting Azure VM Managed Service identity (MSI) Bearer Token.
        VERBOSE: GET http://localhost:50342/oauth2/token?resource=https:%2F%2Fmanagement.azure.com%2F with 0-byte payload
        VERBOSE: received 1335-byte response of content type application/json
        VERBOSE: Getting Storage Key for storage account where File Share will be created.
        VERBOSE: POST https://management.azure.com/subscriptions/28fb33dd-25f0-49a0-926f-72236b87290b/resourceGroups/test42-hostedpi-test-rg/providers/Microsoft.Storage/storageAccounts/tststdjg4jfwskst/listKeys/?api-version=2017-10-01 with 0-byte payload
        VERBOSE: received 288-byte response of content type application/json
        VERBOSE: Generating request header.
        VERBOSE: Executing GET call to check for share.
        VERBOSE: Share URI: https://tststdjg4jfwskst.file.core.windows.net/witness?restype=share.
        VERBOSE: GET https://tststdjg4jfwskst.file.core.windows.net/witness?restype=share with 0-byte payload
        VERBOSE: received -1-byte response of content type 
        VERBOSE: Share found. Status Code: 200
    True
.NOTES
    This function tests for an Azure File Share. It's intended purpose is to be utilized by the corresponding DSC Configuration resource used by OSIsoft
    Hosted PI deployments. To avoid embedded credentials in scripts, this function leverages the Azure REST API to generate a call to create the Azure File Share.
    As prerequisite, it requires the virtual machine on which it is execute to have a Managed Service Identity (MSI) VM extension installed. Also, the VM's MSI must have
    sufficient permissions to modify the storage account resource. (If using the built in RBAC roles in Azure, you can use the Contributor role, but ensure 
    it is scoped to the target storage account only!). The test makes a GET call for the specified Azure File Share properties as this is a more explciti call for 
    a specific Azure File Share instance.
#>
function Get-CreateAzureFileShare {
    [CmdletBinding()]
    [OutputType([hashtable])]
    param(
        # Subscription ID containing storage account for file share.
        [Parameter(Mandatory = $true)]
        [string]$subscriptionId,

        # Resource Group containing storage account.
        [Parameter(Mandatory = $true)]
        $storageResourceGroup,
        
        # Storage account for file share.
        [Parameter(Mandatory = $true)]
        $storageAccount,

        # Name for File Share
        [Parameter(Mandatory = $true)]
        $storageShare
    )

    begin {
        Try {
            # Get Bearer Token
            Write-Verbose -Message "Getting Azure VM Managed Service identity (MSI) Bearer Token." -Verbose
            $response = Invoke-WebRequest -Uri http://localhost:50342/oauth2/token -Method GET -UseBasicParsing -Body @{resource = "https://management.azure.com/"} -Headers @{Metadata = "true"}
            $content = $response.Content | ConvertFrom-Json
            $ArmToken = $content.access_token
        }

        Catch {
            Write-Error $_
            throw 'Unable to Azure VM Managed Service identity (MSI) Bearer Token. See error for details.'
        }

    }

    process {
        Try {
            # Get Primary Key from Storage Account
            Write-Verbose -Message "Getting Storage Key for storage account where File Share will be created." -Verbose
            $keysResponse = Invoke-WebRequest -Uri "https://management.azure.com/subscriptions/$subscriptionId/resourceGroups/$storageResourceGroup/providers/Microsoft.Storage/storageAccounts/$storageAccount/listKeys/?api-version=2017-10-01" -Method POST -UseBasicParsing -Headers @{Authorization = "Bearer $ARMToken"}
            $keysContent = $keysResponse.Content | ConvertFrom-Json
            $storageKey = $keysContent.keys[0].value  # Account Key
        }

        Catch {
            Write-Error $_
            throw 'Unable to Azure Storage Account Key. See error for details.'
        }


        Try {
            # Build CanonicalizedHeaders for REST API call.
            Write-Verbose -Message "Generating request header." -Verbose
            $headers = @{}
            $headers.Add("x-ms-version", "2017-04-17")               # API Version
            [DateTime]$UtcTime = (Get-Date ).ToUniversalTime()
            $headerDate = (Get-Date -Date $UtcTime -Format r)
            $headers.Add("x-ms-date", "$headerDate")                 # Request date in UTC and RFC1123 format

            # Build Signature String
            $signatureString = "GET$([char]10)$([char]10)$([char]10)$([char]10)$([char]10)$([char]10)$([char]10)$([char]10)$([char]10)$([char]10)$([char]10)$([char]10)"
            $signatureString += "x-ms-date:" + $headers["x-ms-date"] + "$([char]10)"
            $signatureString += "x-ms-version:" + $headers["x-ms-version"] + "$([char]10)"

            # Add CanonicalizedResource
            $signatureString += "/" + $storageAccount + "/" + $storageShare + "$([char]10)" + "restype:share"

            # Encoding Signature
            $dataToMac = [System.Text.Encoding]::UTF8.GetBytes($signatureString)
            $accountKeyBytes = [System.Convert]::FromBase64String($storageKey)
            $hmac = New-Object System.Security.Cryptography.HMACSHA256((, $accountKeyBytes))
            $signature = [System.Convert]::ToBase64String($hmac.ComputeHash($dataToMac))
            $headers.Add("Authorization", "SharedKey " + $StorageAccount + ":" + $signature)   # Add encoded signature to Header
        }

        Catch {
            Write-Error $_
            throw 'Unable to generate REST API headers. See error for details.'
        }


        Try {
            ## This call checks for the Share. Response 200 = Share exists. Exception = Share not Found
            $newShareUri = "https://" + $storageAccount + ".file.core.windows.net/" + $storageShare + "?restype=share"
            Write-Verbose -Message "Executing GET call to check for share." -Verbose
            Write-Verbose -Message "Share URI: $($newShareUri)." -Verbose
            $getResponse = Invoke-WebRequest -Uri $newShareUri -Method GET -UseBasicParsing -Headers $headers -ErrorAction Stop

            # If Share is found, expect a 200 response and return $true
            if ($getResponse.StatusCode -eq 200) {
                $returnedValue = @{
                    StatusCode = $getResponse.StatusCode
                }
                return $returnedValue
            }
            else {
                $returnedValue = @{
                    StatusCode = $getResponse.StatusCode
                }
                return $returnedValue
            }
        }

        # If Share not found, expect exception of type System.net.WebException. Indicates share's absence and therefore needs creating.
        Catch [System.Net.WebException] {
            $getErr = $Error[0]
            $shareNotFound = $getErr.ErrorDetails.Message -like "*The specified share does not exist*"
            if ($shareNotFound) {
                Write-Warning -Message "Share $($storageShare) was not found. Exception thrown with no response." -Verbose
                $returnedValue = @{
                    StatusCode = '404'
                }
                return $returnedValue
            }
            else {
                Write-Warning -Message "Share $($storageShare) was not found." -Verbose
                Write-Warning -Message "Exception: $($getErr.Exception.Message)" -Verbose
                $returnedValue = @{
                    StatusCode = '404'
                }
                return $returnedValue
            }
        }

        # Catch any other error and output
        Catch {
            Write-Error $_
            throw 'Unable to get Azure File Share. See error for details.'
        }
    }

    end {
    }
}
# SIG # Begin signature block
# MIIcVgYJKoZIhvcNAQcCoIIcRzCCHEMCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCEoVrQUF0Ps9ro
# vOxzO2NKOMUObRd2LDewYGoRD1pSwqCCCo0wggUwMIIEGKADAgECAhAECRgbX9W7
# ZnVTQ7VvlVAIMA0GCSqGSIb3DQEBCwUAMGUxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xJDAiBgNV
# BAMTG0RpZ2lDZXJ0IEFzc3VyZWQgSUQgUm9vdCBDQTAeFw0xMzEwMjIxMjAwMDBa
# Fw0yODEwMjIxMjAwMDBaMHIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2Vy
# dCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xMTAvBgNVBAMTKERpZ2lD
# ZXJ0IFNIQTIgQXNzdXJlZCBJRCBDb2RlIFNpZ25pbmcgQ0EwggEiMA0GCSqGSIb3
# DQEBAQUAA4IBDwAwggEKAoIBAQD407Mcfw4Rr2d3B9MLMUkZz9D7RZmxOttE9X/l
# qJ3bMtdx6nadBS63j/qSQ8Cl+YnUNxnXtqrwnIal2CWsDnkoOn7p0WfTxvspJ8fT
# eyOU5JEjlpB3gvmhhCNmElQzUHSxKCa7JGnCwlLyFGeKiUXULaGj6YgsIJWuHEqH
# CN8M9eJNYBi+qsSyrnAxZjNxPqxwoqvOf+l8y5Kh5TsxHM/q8grkV7tKtel05iv+
# bMt+dDk2DZDv5LVOpKnqagqrhPOsZ061xPeM0SAlI+sIZD5SlsHyDxL0xY4PwaLo
# LFH3c7y9hbFig3NBggfkOItqcyDQD2RzPJ6fpjOp/RnfJZPRAgMBAAGjggHNMIIB
# yTASBgNVHRMBAf8ECDAGAQH/AgEAMA4GA1UdDwEB/wQEAwIBhjATBgNVHSUEDDAK
# BggrBgEFBQcDAzB5BggrBgEFBQcBAQRtMGswJAYIKwYBBQUHMAGGGGh0dHA6Ly9v
# Y3NwLmRpZ2ljZXJ0LmNvbTBDBggrBgEFBQcwAoY3aHR0cDovL2NhY2VydHMuZGln
# aWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEUm9vdENBLmNydDCBgQYDVR0fBHow
# eDA6oDigNoY0aHR0cDovL2NybDQuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJl
# ZElEUm9vdENBLmNybDA6oDigNoY0aHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0Rp
# Z2lDZXJ0QXNzdXJlZElEUm9vdENBLmNybDBPBgNVHSAESDBGMDgGCmCGSAGG/WwA
# AgQwKjAoBggrBgEFBQcCARYcaHR0cHM6Ly93d3cuZGlnaWNlcnQuY29tL0NQUzAK
# BghghkgBhv1sAzAdBgNVHQ4EFgQUWsS5eyoKo6XqcQPAYPkt9mV1DlgwHwYDVR0j
# BBgwFoAUReuir/SSy4IxLVGLp6chnfNtyA8wDQYJKoZIhvcNAQELBQADggEBAD7s
# DVoks/Mi0RXILHwlKXaoHV0cLToaxO8wYdd+C2D9wz0PxK+L/e8q3yBVN7Dh9tGS
# dQ9RtG6ljlriXiSBThCk7j9xjmMOE0ut119EefM2FAaK95xGTlz/kLEbBw6RFfu6
# r7VRwo0kriTGxycqoSkoGjpxKAI8LpGjwCUR4pwUR6F6aGivm6dcIFzZcbEMj7uo
# +MUSaJ/PQMtARKUT8OZkDCUIQjKyNookAv4vcn4c10lFluhZHen6dGRrsutmQ9qz
# sIzV6Q3d9gEgzpkxYz0IGhizgZtPxpMQBvwHgfqL2vmCSfdibqFT+hKUGIUukpHq
# aGxEMrJmoecYpJpkUe8wggVVMIIEPaADAgECAhAGVvq6kseGimsYGJGsdvpbMA0G
# CSqGSIb3DQEBCwUAMHIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJ
# bmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xMTAvBgNVBAMTKERpZ2lDZXJ0
# IFNIQTIgQXNzdXJlZCBJRCBDb2RlIFNpZ25pbmcgQ0EwHhcNMjAwNjE2MDAwMDAw
# WhcNMjIwNzIyMTIwMDAwWjCBkTELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRQw
# EgYDVQQHEwtTYW4gTGVhbmRybzEVMBMGA1UEChMMT1NJc29mdCwgTExDMQwwCgYD
# VQQLEwNEZXYxFTATBgNVBAMTDE9TSXNvZnQsIExMQzEjMCEGCSqGSIb3DQEJARYU
# cGRlcmVnaWxAb3Npc29mdC5jb20wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEK
# AoIBAQDPSOGDHDmQTrdWSTB6jfvZ3+ngv2HwU/64ZUGKq+PbyQKcqeRI5MT2Fokj
# K9yp6JoVnipZaBZdjLRj//FuqDR/pNy3VZo1xmufKICqrSS6x2AxKb9l/6mcO/MF
# E2FgG0tND/xftCQlChB91GokCyiVNkwbLleB9uM6yn73ZZkiA0Chmjguipfal+hS
# 27vds5xYGLtcnqWcKcZR5pr838vDT+8zzrxoWQ8se3H9LHYLyCiwk+84mA1M//BW
# xaA7ERt1eJ3vLzYu3+ryH+GFiYEhJHu3FZjktEg5oZ25Vj7iwgTG+/CIMZsEDe5G
# SFvePn3jpMmEaPbOPfx8FVwh8XItAgMBAAGjggHFMIIBwTAfBgNVHSMEGDAWgBRa
# xLl7KgqjpepxA8Bg+S32ZXUOWDAdBgNVHQ4EFgQUmzSViihexjjLsHHW6j+r7Fxw
# U/gwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoGCCsGAQUFBwMDMHcGA1UdHwRw
# MG4wNaAzoDGGL2h0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9zaGEyLWFzc3VyZWQt
# Y3MtZzEuY3JsMDWgM6Axhi9odHRwOi8vY3JsNC5kaWdpY2VydC5jb20vc2hhMi1h
# c3N1cmVkLWNzLWcxLmNybDBMBgNVHSAERTBDMDcGCWCGSAGG/WwDATAqMCgGCCsG
# AQUFBwIBFhxodHRwczovL3d3dy5kaWdpY2VydC5jb20vQ1BTMAgGBmeBDAEEATCB
# hAYIKwYBBQUHAQEEeDB2MCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5kaWdpY2Vy
# dC5jb20wTgYIKwYBBQUHMAKGQmh0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNvbS9E
# aWdpQ2VydFNIQTJBc3N1cmVkSURDb2RlU2lnbmluZ0NBLmNydDAMBgNVHRMBAf8E
# AjAAMA0GCSqGSIb3DQEBCwUAA4IBAQAR/2LHTPvx/fBATBS0jBBhPEhlrpNgkWZ9
# NCo0wJC5H2V2CpokuZxA4HoK0YCsz2x68BpCnBOX3pdSWC+kQOvLyJayTQew+c/R
# sebGEVp9NNtsnpcFhjM3e7hqsQAm6rCIJWk0Q1sSyYnhnqHA/iS1DxNqZ/qZHx1k
# ise1+9bOefqB1YN+vtmPBlLkboKCklbrJmHSEn4cZNBHjq1yVYOPacuws+8kAEMh
# lDjG2NkfyqF72Jo90SFK7xgjE6euLbvmjGYRSF9h4V+aR6MaEcDkUe2aoCgCmnDX
# Q+9sIKX0AojqBVLFUNQpzelOdjGWNzdcMMSu8p0pNw4xeAbuCEHfMYIRHzCCERsC
# AQEwgYYwcjELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0IEluYzEZMBcG
# A1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTExMC8GA1UEAxMoRGlnaUNlcnQgU0hBMiBB
# c3N1cmVkIElEIENvZGUgU2lnbmluZyBDQQIQBlb6upLHhoprGBiRrHb6WzANBglg
# hkgBZQMEAgEFAKCBnjAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgorBgEE
# AYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgbLGAcvhHRE2h
# UWMdIzCVH7MNwC9O9bcPzmujsrEp8T4wMgYKKwYBBAGCNwIBDDEkMCKhIIAeaHR0
# cDovL3RlY2hzdXBwb3J0Lm9zaXNvZnQuY29tMA0GCSqGSIb3DQEBAQUABIIBAMrf
# 78HpPGxmOAl/UzCoUgZbAt7VaLrJLp020p+H/2mIjCXKEzUtKEQSs8pb4aYMxvCP
# 8qdgWaHpM/ZcL+4YyfSp6Z3kMCcZuTMEp46P2GZVDIP4GeVJ8u9NFMsN+KgKQMI2
# TM9J48xvtesQh8wp08Esqlff45cRi0czUgXaS6Dnk9hQLWtBapQG2Ko37Kk1aFD9
# ms8iFQa/kOQZpmT0l1qdpL9q2Ukpar37nGN2CfSgnmf1h11nvPumgp2kLoIDdCBW
# FLpqfQXBK7j27SUCpva+HwC3RZ1roIaK0Jz1zkvrZfRBFM4oNeC+x6DQglTmhY2G
# IMYddnWQECyuqgEwdUqhgg7IMIIOxAYKKwYBBAGCNwMDATGCDrQwgg6wBgkqhkiG
# 9w0BBwKggg6hMIIOnQIBAzEPMA0GCWCGSAFlAwQCAQUAMHcGCyqGSIb3DQEJEAEE
# oGgEZjBkAgEBBglghkgBhv1sBwEwMTANBglghkgBZQMEAgEFAAQgqSGnqewbuWlb
# SvZe5QloUpoY3agFJL//Lob82BIEZNMCEBJG+ybKpLSY6Q/bW+H71aUYDzIwMjAx
# MTA0MjA1NjIxWqCCC7swggaCMIIFaqADAgECAhAEzT+FaK52xhuw/nFgzKdtMA0G
# CSqGSIb3DQEBCwUAMHIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJ
# bmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xMTAvBgNVBAMTKERpZ2lDZXJ0
# IFNIQTIgQXNzdXJlZCBJRCBUaW1lc3RhbXBpbmcgQ0EwHhcNMTkxMDAxMDAwMDAw
# WhcNMzAxMDE3MDAwMDAwWjBMMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNl
# cnQsIEluYy4xJDAiBgNVBAMTG1RJTUVTVEFNUC1TSEEyNTYtMjAxOS0xMC0xNTCC
# ASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAOlkNZz6qZhlZBvkF9y4KTbM
# ZwlYhU0w4Mn/5Ts8EShQrwcx4l0JGML2iYxpCAQj4HctnRXluOihao7/1K7Sehbv
# +EG1HTl1wc8vp6xFfpRtrAMBmTxiPn56/UWXMbT6t9lCPqdVm99aT1gCqDJpIhO+
# i4Itxpira5u0yfJlEQx0DbLwCJZ0xOiySKKhFKX4+uGJcEQ7je/7pPTDub0ULOsM
# KCclgKsQSxYSYAtpIoxOzcbVsmVZIeB8LBKNcA6Pisrg09ezOXdQ0EIsLnrOnGd6
# OHdUQP9PlQQg1OvIzocUCP4dgN3Q5yt46r8fcMbuQhZTNkWbUxlJYp16ApuVFKMC
# AwEAAaOCAzgwggM0MA4GA1UdDwEB/wQEAwIHgDAMBgNVHRMBAf8EAjAAMBYGA1Ud
# JQEB/wQMMAoGCCsGAQUFBwMIMIIBvwYDVR0gBIIBtjCCAbIwggGhBglghkgBhv1s
# BwEwggGSMCgGCCsGAQUFBwIBFhxodHRwczovL3d3dy5kaWdpY2VydC5jb20vQ1BT
# MIIBZAYIKwYBBQUHAgIwggFWHoIBUgBBAG4AeQAgAHUAcwBlACAAbwBmACAAdABo
# AGkAcwAgAEMAZQByAHQAaQBmAGkAYwBhAHQAZQAgAGMAbwBuAHMAdABpAHQAdQB0
# AGUAcwAgAGEAYwBjAGUAcAB0AGEAbgBjAGUAIABvAGYAIAB0AGgAZQAgAEQAaQBn
# AGkAQwBlAHIAdAAgAEMAUAAvAEMAUABTACAAYQBuAGQAIAB0AGgAZQAgAFIAZQBs
# AHkAaQBuAGcAIABQAGEAcgB0AHkAIABBAGcAcgBlAGUAbQBlAG4AdAAgAHcAaABp
# AGMAaAAgAGwAaQBtAGkAdAAgAGwAaQBhAGIAaQBsAGkAdAB5ACAAYQBuAGQAIABh
# AHIAZQAgAGkAbgBjAG8AcgBwAG8AcgBhAHQAZQBkACAAaABlAHIAZQBpAG4AIABi
# AHkAIAByAGUAZgBlAHIAZQBuAGMAZQAuMAsGCWCGSAGG/WwDFTAfBgNVHSMEGDAW
# gBT0tuEgHf4prtLkYaWyoiWyyBc1bjAdBgNVHQ4EFgQUVlMPwcYHp03X2G5XcoBQ
# TOTsnsEwcQYDVR0fBGowaDAyoDCgLoYsaHR0cDovL2NybDMuZGlnaWNlcnQuY29t
# L3NoYTItYXNzdXJlZC10cy5jcmwwMqAwoC6GLGh0dHA6Ly9jcmw0LmRpZ2ljZXJ0
# LmNvbS9zaGEyLWFzc3VyZWQtdHMuY3JsMIGFBggrBgEFBQcBAQR5MHcwJAYIKwYB
# BQUHMAGGGGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBPBggrBgEFBQcwAoZDaHR0
# cDovL2NhY2VydHMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0U0hBMkFzc3VyZWRJRFRp
# bWVzdGFtcGluZ0NBLmNydDANBgkqhkiG9w0BAQsFAAOCAQEALoOhRAVKBOO5MlL6
# 2YHwGrv4CY0juT3YkqHmRhxKL256PGNuNxejGr9YI7JDnJSDTjkJsCzox+HizO3L
# eWvO3iMBR+2VVIHggHsSsa8Chqk6c2r++J/BjdEhjOQpgsOKC2AAAp0fR8SftApo
# U39aEKb4Iub4U5IxX9iCgy1tE0Kug8EQTqQk9Eec3g8icndcf0/pOZgrV5JE1+9u
# k9lDxwQzY1E3Vp5HBBHDo1hUIdjijlbXST9X/AqfI1579JSN3Z0au996KqbSRaZV
# DI/2TIryls+JRtwxspGQo18zMGBV9fxrMKyh7eRHTjOeZ2ootU3C7VuXgvjLqQhs
# Uwm09zCCBTEwggQZoAMCAQICEAqhJdbWMht+QeQF2jaXwhUwDQYJKoZIhvcNAQEL
# BQAwZTELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0IEluYzEZMBcGA1UE
# CxMQd3d3LmRpZ2ljZXJ0LmNvbTEkMCIGA1UEAxMbRGlnaUNlcnQgQXNzdXJlZCBJ
# RCBSb290IENBMB4XDTE2MDEwNzEyMDAwMFoXDTMxMDEwNzEyMDAwMFowcjELMAkG
# A1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0IEluYzEZMBcGA1UECxMQd3d3LmRp
# Z2ljZXJ0LmNvbTExMC8GA1UEAxMoRGlnaUNlcnQgU0hBMiBBc3N1cmVkIElEIFRp
# bWVzdGFtcGluZyBDQTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAL3Q
# Mu5LzY9/3am6gpnFOVQoV7YjSsQOB0UzURB90Pl9TWh+57ag9I2ziOSXv2MhkJi/
# E7xX08PhfgjWahQAOPcuHjvuzKb2Mln+X2U/4Jvr40ZHBhpVfgsnfsCi9aDg3iI/
# Dv9+lfvzo7oiPhisEeTwmQNtO4V8CdPuXciaC1TjqAlxa+DPIhAPdc9xck4Krd9A
# Oly3UeGheRTGTSQjMF287DxgaqwvB8z98OpH2YhQXv1mblZhJymJhFHmgudGUP2U
# Kiyn5HU+upgPhH+fMRTWrdXyZMt7HgXQhBlyF/EXBu89zdZN7wZC/aJTKk+FHcQd
# PK/P2qwQ9d2srOlW/5MCAwEAAaOCAc4wggHKMB0GA1UdDgQWBBT0tuEgHf4prtLk
# YaWyoiWyyBc1bjAfBgNVHSMEGDAWgBRF66Kv9JLLgjEtUYunpyGd823IDzASBgNV
# HRMBAf8ECDAGAQH/AgEAMA4GA1UdDwEB/wQEAwIBhjATBgNVHSUEDDAKBggrBgEF
# BQcDCDB5BggrBgEFBQcBAQRtMGswJAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3NwLmRp
# Z2ljZXJ0LmNvbTBDBggrBgEFBQcwAoY3aHR0cDovL2NhY2VydHMuZGlnaWNlcnQu
# Y29tL0RpZ2lDZXJ0QXNzdXJlZElEUm9vdENBLmNydDCBgQYDVR0fBHoweDA6oDig
# NoY0aHR0cDovL2NybDQuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEUm9v
# dENBLmNybDA6oDigNoY0aHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0
# QXNzdXJlZElEUm9vdENBLmNybDBQBgNVHSAESTBHMDgGCmCGSAGG/WwAAgQwKjAo
# BggrBgEFBQcCARYcaHR0cHM6Ly93d3cuZGlnaWNlcnQuY29tL0NQUzALBglghkgB
# hv1sBwEwDQYJKoZIhvcNAQELBQADggEBAHGVEulRh1Zpze/d2nyqY3qzeM8GN0CE
# 70uEv8rPAwL9xafDDiBCLK938ysfDCFaKrcFNB1qrpn4J6JmvwmqYN92pDqTD/iy
# 0dh8GWLoXoIlHsS6HHssIeLWWywUNUMEaLLbdQLgcseY1jxk5R9IEBhfiThhTWJG
# JIdjjJFSLK8pieV4H9YLFKWA1xJHcLN11ZOFk362kmf7U2GJqPVrlsD0WGkNfMgB
# sbkodbeZY4UijGHKeZR+WfyMD+NvtQEmtmyl7odRIeRYYJu6DC0rbaLEfrvEJStH
# Agh8Sa4TtuF8QkIoxhhWz0E0tmZdtnR79VYzIi8iNrJLokqV2PWmjlIxggJNMIIC
# SQIBATCBhjByMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkw
# FwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMTEwLwYDVQQDEyhEaWdpQ2VydCBTSEEy
# IEFzc3VyZWQgSUQgVGltZXN0YW1waW5nIENBAhAEzT+FaK52xhuw/nFgzKdtMA0G
# CWCGSAFlAwQCAQUAoIGYMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAcBgkq
# hkiG9w0BCQUxDxcNMjAxMTA0MjA1NjIxWjArBgsqhkiG9w0BCRACDDEcMBowGDAW
# BBQDJb1QXtqWMC3CL0+gHkwovig0xTAvBgkqhkiG9w0BCQQxIgQgU8OgsF6t2yYe
# RNb6Y1BSsdlnVe0iwmQ+zz69mqqid+EwDQYJKoZIhvcNAQEBBQAEggEABoYTEPa9
# ezJUGyZZ8AfM1bsvlkuY3tQDcV+NGh5198Pg19OmZWYyofRjfqiemucuMoYV7m8L
# f5DLL25qyaYSFCrx6Tdw+t8JCFQdhViU+1L5hRgoCgV0FWznZtVRQJb+frGDG9FT
# FwDzw27xKML781KmXR5cMv/WuY6g78A1NRV+22PALp/+UYSaYbN0UURf5EWrCua5
# 1LMl1Kl1E3GJX/5vF77FMXcBxm9CL6gXJ9q+41ooN/7FVjO9jTf56S7am9xgrg3u
# YN5T2RO6C3Ou/iXvpwlczZ3dVNJxj1ROJcohPWvCyyU1GOnhs9A2CL8dIfex4R9x
# +Ww9j8lMp92kBQ==
# SIG # End signature block
