﻿<#
    .SYNOPSIS
    Creates clustered generic service resource. Tuned for PI Analytics and PI Notifications deployments.
    .DESCRIPTION
    This is a helper function used by HostedPI-DSC module. This function is used in the Set portion of the DSC to configure a clustered service resource.
    .NOTES
    This functions purpose is to go throught the multi step process to add a Generic Service resource to a pre-existing Windows Failover cluster.
    The cluster must already exist prior to executing this function. The function is targeted specifically for PI Analytics and PI Notifications
    deployments for failover configuration. Note that for Azure deployments, the lbIPAddress corresponds to the frontend private IP of an internal
    load balancer which is necessary for Azure networking. For on-prem deployments, this simply needs to be an vacant available IP that the cluster 
    can use to use identify the service resource.
    .EXAMPLE
    This example shows the configuration for a clustered service resource called 'PIAN0-CLSTSVC' for PI Analytics. The service becomes available as a
    clustered resource on IP 10.207.0.188 and by the DNS entry for PIAN0-CLSTSVC.mydomain.int (assuming FQDN is mydomain.int).
    PS C:\> Set-PIAnalyticsClusteredService -clusterResourceName 'PIAN0-CLSTSVC' -lbIPAddress '10.207.0.188' -serviceName PIAnalysisManager -Verbose
        VERBOSE: 1. Create Cluster Group - Add Cluster Group
        VERBOSE: Connecting to cluster on local computer tst-pian-vm0.

        VERBOSE: 2. Generic Service - Add Network Resource.
        VERBOSE: Connecting to cluster on local computer tst-pian-vm0.
        VERBOSE: 3. IP Resource - Add IP Address + Set IPAddress/SubnetMask/ProbePort
        VERBOSE: Connecting to cluster on local computer tst-pian-vm0.
        Name          OwnerNode    State 
        ----          ---------    ----- 
        PIAN0-CLSTSVC tst-pian-vm0 Online

        Name         : PI Analysis Service
        State        : Offline
        OwnerGroup   : PIAN0-CLSTSVC
        ResourceType : Generic Service


        Name         : IP Address_10.207.0.188
        State        : Offline
        OwnerGroup   : PIAN0-CLSTSVC
        ResourceType : IP Address

        VERBOSE: Connecting to cluster on local computer tst-pian-vm0.
        VERBOSE: 4. Network Name - Add Network Name Resource, Set dependency on IP Resource, Set DNS Entry
        VERBOSE: Connecting to cluster on local computer tst-pian-vm0.

        Name         : PIAN0-CLSTSVC
        State        : Offline
        OwnerGroup   : PIAN0-CLSTSVC
        ResourceType : Network Name

        VERBOSE: Connecting to cluster on local computer tst-pian-vm0.
        VERBOSE: Connecting to cluster on local computer tst-pian-vm0.
        VERBOSE: 5. Generic Service - Set Registry entry, Add Dependency on Network Name, Add Service Name + Enable Use Network Name
        VERBOSE: Connecting to cluster on local computer tst-pian-vm0.

        Resource : PI Analysis Service
        Name     : SOFTWARE\PISystem\Analysis Service

        VERBOSE: Connecting to cluster on local computer tst-pian-vm0.
        VERBOSE: Connecting to cluster on local computer tst-pian-vm0.
        VERBOSE: 6. Restarting cluster resources to ensure the service is brought online.
        VERBOSE: Connecting to cluster on local computer tst-pian-vm0.
        VERBOSE: Resource 'IP Address_10.207.0.188' is now in state Offline.

        Name         : IP Address_10.207.0.188
        State        : Offline
        OwnerGroup   : PIAN0-CLSTSVC
        ResourceType : IP Address

        VERBOSE: Connecting to cluster on local computer tst-pian-vm0.
        VERBOSE: Resource 'PIAN0-CLSTSVC' is now in state Offline.

        Name         : PIAN0-CLSTSVC
        State        : Offline
        OwnerGroup   : PIAN0-CLSTSVC
        ResourceType : Network Name

        VERBOSE: Connecting to cluster on local computer tst-pian-vm0.
        VERBOSE: Resource 'PI Analysis Service' is now in state Offline.

        Name         : PI Analysis Service
        State        : Offline
        OwnerGroup   : PIAN0-CLSTSVC
        ResourceType : Generic Service

        VERBOSE: Connecting to cluster on local computer tst-pian-vm0.
        VERBOSE: Resource 'PIAN0-CLSTSVC' is now in state Online.

        Name         : PIAN0-CLSTSVC
        State        : Online
        OwnerGroup   : PIAN0-CLSTSVC
        ResourceType : Network Name

        VERBOSE: Connecting to cluster on local computer tst-pian-vm0.
        VERBOSE: Resource 'IP Address_10.207.0.188' is now in state Online.

        Name         : IP Address_10.207.0.188
        State        : Online
        OwnerGroup   : PIAN0-CLSTSVC
        ResourceType : IP Address

        VERBOSE: Connecting to cluster on local computer tst-pian-vm0.
        VERBOSE: Resource 'PI Analysis Service' is now in state Online.

        Name         : PI Analysis Service
        State        : Online
        OwnerGroup   : PIAN0-CLSTSVC
        ResourceType : Generic Service

        VERBOSE: 7. Cluster resources restarted and online.

#>
function Set-PIAnalyticsClusteredService {
    param(
        # Name used to identify clustered service resource. This appears in DNS, e.g. 'PIAN0-CLSTSVC'.
        [Parameter(Mandatory = $true)]
        [string]$clusterResourceName,

        # IP Address for service resource. For Azure deployments, this corresponds to the internal load balancer private IP address.
        [Parameter(Mandatory = $true)]
        [string]$lbIPAddress,

        # Subnet mask applied to IP resource.
        [Parameter()]
        [string]$subnetMask = '255.255.255.192',

        # Service name of service that will become the clustered resource.
        [Parameter()]
        [ValidateSet('PIAnalysisManager')]
        [string]$serviceName = 'PIAnalysisManager'    
    )
  
    # Registry entry associated with clustered resource for the service.
    [string]$registryCheckpoint = 'SOFTWARE\PISystem\Analysis Service'

    # Aggregate properties for setting Network Resource Name
    [string]$networkResource = $serviceName                 # Use Service name for simplicity
    [string]$ipResource = "IP Address_" + $lbIPAddress      # Concatenate IP Resource Name
    [System.UInt32]$UseNetworkName = 1                      # Cast input to correct type.
  
  
    #region 1. Create Cluster Group - Add Cluster Group
    Try {
        Write-Verbose -Message "1. Create Cluster Group - Add Cluster Group" -Verbose
        Add-ClusterGroup -Name $clusterResourceName -GroupType GenericService -ErrorAction Stop 
    }
    
    Catch [Microsoft.FailoverClusters.PowerShell.ClusterCmdletException] {
        Write-Warning -Message "$_.ErrorDetails.Message"
        Write-Verbose -Message "Resource Group $clusterResourceName already exists." -Verbose
    }
    
    Catch {
        Write-Error $_
    }
    #endregion 1. Create Cluster group
  
  
    #region 2. Generic Service - Add Network Resource.
    Try {
        Write-Verbose -Message "2. Generic Service - Add Network Resource." -Verbose
        Add-ClusterResource -Name $networkResource -ResourceType "Generic Service" -Group $clusterResourceName -ErrorAction Stop 
    }
    Catch [Microsoft.FailoverClusters.PowerShell.ClusterCmdletException] {
        Write-Warning -Message "$_.ErrorDetails.Message"
        Write-Verbose -Message "CLuster role $networkResource already exists." -Verbose
    }
    Catch {
        Write-Error $_
        Continue
    }
    #endregion 2. Generic Service - Add Network Resource.
  
  
    #region 3. IP Resource - Add IP Address + Set IPAddress/SubnetMask/ProbePort
    Try {
        Write-Verbose -Message "3. IP Resource - Add IP Address + Set IPAddress/SubnetMask/ProbePort" -Verbose
        Add-ClusterResource -Name $ipResource -ResourceType "IP Address" -Group $clusterResourceName -ErrorAction Stop
    }    
    Catch [Microsoft.FailoverClusters.PowerShell.ClusterCmdletException] {
        Write-Warning -Message "$_.ErrorDetails.Message"
        Write-Verbose -Message "IP resource $ipResource already exists." -Verbose
    }
    Catch {
        Write-Error $_
        Continue
    }
    
    Try {
        Get-ClusterResource -Name $ipResource -ErrorAction Stop |
            Set-ClusterParameter -Multiple @{"Address" = $lbIPAddress; "SubnetMask" = $subnetMask; 'ProbePort' = 59999 } -ErrorAction Stop
    }
    Catch {
        Write-Error $_
        Continue
    }
    #endregion 3. IP Resource - Add IP Address + Set IPAddress/SubnetMask/ProbePort
  
  
    #region 4. Network Name - Add Network Name Resource, Set dependency on IP Resource, Set DNS Entry
    Try {
        Write-Verbose -Message "4. Network Name - Add Network Name Resource, Set dependency on IP Resource, Set DNS Entry" -Verbose
        Add-ClusterResource -Name $clusterResourceName -ResourceType "Network Name" -Group $clusterResourceName  -ErrorAction Stop
    }
    Catch [Microsoft.FailoverClusters.PowerShell.ClusterCmdletException] {
        Write-Warning -Message "$_.ErrorDetails.Message"
        Write-Verbose -Message "Network resource $clusterResourceName already exists." -Verbose
    }
    
    Try {
        Get-ClusterResource -Name $clusterResourceName -ErrorAction Stop |
            Set-ClusterResourceDependency -Resource $clusterResourceName -Dependency "[$ipResource]" -ErrorAction Stop 
      
        Get-ClusterResource -Name $clusterResourceName -ErrorAction Stop |
            Set-ClusterParameter -Multiple @{"DnsName" = $clusterResourceName; "Name" = $clusterResourceName } -ErrorAction Stop 
    }
    Catch {
        Write-Error $_
        Continue
    }
    #endregion 4. Network Name - Add Network Name Resource, Set dependency on IP Resource, Set DNS Entry
  
  
    #region 5. Generic Service - Set Registry entry, Add Dependency on Network Name, Add Service Name + Enable Use Network Name
    Try {
        Write-Verbose -Message "5. Generic Service - Set Registry entry, Add Dependency on Network Name, Add Service Name + Enable Use Network Name" -Verbose
        Add-ClusterCheckpoint -ResourceName $networkResource -RegistryCheckpoint $registryCheckpoint -ErrorAction Stop 
    }
    Catch [Microsoft.FailoverClusters.PowerShell.ClusterCmdletException] {
        Write-Warning -Message "$_.ErrorDetails.Message"
        Write-Verbose -Message "RegisteryCheckPoint $registryCheckpoint already exists." -Verbose
    }
    Catch {
        Write-Error $_
        Continue
    }
    
    Try {
        Get-ClusterResource -Name $networkResource -ErrorAction Stop |
            Set-ClusterResourceDependency -Resource $networkResource -Dependency "[$clusterResourceName]" -ErrorAction Stop
      
        Get-ClusterResource -Name $networkResource -ErrorAction Stop |
            Set-ClusterParameter -Multiple @{"ServiceName" = $serviceName; "UseNetworkName" = "$UseNetworkName"} -ErrorAction Stop 
      
        ## Ensure all resources are stopped
        Write-Verbose -Message "6. Restarting cluster resources to ensure the service is brought online." -Verbose
        Stop-ClusterResource $ipResource -ErrorAction Stop 
        Stop-ClusterResource $clusterResourceName -ErrorAction Stop 
        Stop-ClusterResource $networkResource -ErrorAction Stop 
      
        ## Start all resources
        Start-ClusterResource $clusterResourceName -ErrorAction Stop 
        Start-ClusterResource $ipResource -ErrorAction Stop 
        Start-ClusterResource $networkResource -ErrorAction Stop
        Write-Verbose -Message "7. Cluster resources restarted and online." -Verbose
    }
    Catch {
        Write-Error $_
    }
    #endregion 5. Generic Service - Set Registry entry, Add Dependency on Network Name, Add Service Name + Enable Use Network Name
}
# SIG # Begin signature block
# MIIcVgYJKoZIhvcNAQcCoIIcRzCCHEMCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDNJOC+DK+2gdT2
# aeH8wff7qjSVuMl9z35Gj0FXhbGw4qCCCo0wggUwMIIEGKADAgECAhAECRgbX9W7
# ZnVTQ7VvlVAIMA0GCSqGSIb3DQEBCwUAMGUxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xJDAiBgNV
# BAMTG0RpZ2lDZXJ0IEFzc3VyZWQgSUQgUm9vdCBDQTAeFw0xMzEwMjIxMjAwMDBa
# Fw0yODEwMjIxMjAwMDBaMHIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2Vy
# dCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xMTAvBgNVBAMTKERpZ2lD
# ZXJ0IFNIQTIgQXNzdXJlZCBJRCBDb2RlIFNpZ25pbmcgQ0EwggEiMA0GCSqGSIb3
# DQEBAQUAA4IBDwAwggEKAoIBAQD407Mcfw4Rr2d3B9MLMUkZz9D7RZmxOttE9X/l
# qJ3bMtdx6nadBS63j/qSQ8Cl+YnUNxnXtqrwnIal2CWsDnkoOn7p0WfTxvspJ8fT
# eyOU5JEjlpB3gvmhhCNmElQzUHSxKCa7JGnCwlLyFGeKiUXULaGj6YgsIJWuHEqH
# CN8M9eJNYBi+qsSyrnAxZjNxPqxwoqvOf+l8y5Kh5TsxHM/q8grkV7tKtel05iv+
# bMt+dDk2DZDv5LVOpKnqagqrhPOsZ061xPeM0SAlI+sIZD5SlsHyDxL0xY4PwaLo
# LFH3c7y9hbFig3NBggfkOItqcyDQD2RzPJ6fpjOp/RnfJZPRAgMBAAGjggHNMIIB
# yTASBgNVHRMBAf8ECDAGAQH/AgEAMA4GA1UdDwEB/wQEAwIBhjATBgNVHSUEDDAK
# BggrBgEFBQcDAzB5BggrBgEFBQcBAQRtMGswJAYIKwYBBQUHMAGGGGh0dHA6Ly9v
# Y3NwLmRpZ2ljZXJ0LmNvbTBDBggrBgEFBQcwAoY3aHR0cDovL2NhY2VydHMuZGln
# aWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEUm9vdENBLmNydDCBgQYDVR0fBHow
# eDA6oDigNoY0aHR0cDovL2NybDQuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJl
# ZElEUm9vdENBLmNybDA6oDigNoY0aHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0Rp
# Z2lDZXJ0QXNzdXJlZElEUm9vdENBLmNybDBPBgNVHSAESDBGMDgGCmCGSAGG/WwA
# AgQwKjAoBggrBgEFBQcCARYcaHR0cHM6Ly93d3cuZGlnaWNlcnQuY29tL0NQUzAK
# BghghkgBhv1sAzAdBgNVHQ4EFgQUWsS5eyoKo6XqcQPAYPkt9mV1DlgwHwYDVR0j
# BBgwFoAUReuir/SSy4IxLVGLp6chnfNtyA8wDQYJKoZIhvcNAQELBQADggEBAD7s
# DVoks/Mi0RXILHwlKXaoHV0cLToaxO8wYdd+C2D9wz0PxK+L/e8q3yBVN7Dh9tGS
# dQ9RtG6ljlriXiSBThCk7j9xjmMOE0ut119EefM2FAaK95xGTlz/kLEbBw6RFfu6
# r7VRwo0kriTGxycqoSkoGjpxKAI8LpGjwCUR4pwUR6F6aGivm6dcIFzZcbEMj7uo
# +MUSaJ/PQMtARKUT8OZkDCUIQjKyNookAv4vcn4c10lFluhZHen6dGRrsutmQ9qz
# sIzV6Q3d9gEgzpkxYz0IGhizgZtPxpMQBvwHgfqL2vmCSfdibqFT+hKUGIUukpHq
# aGxEMrJmoecYpJpkUe8wggVVMIIEPaADAgECAhAGVvq6kseGimsYGJGsdvpbMA0G
# CSqGSIb3DQEBCwUAMHIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJ
# bmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xMTAvBgNVBAMTKERpZ2lDZXJ0
# IFNIQTIgQXNzdXJlZCBJRCBDb2RlIFNpZ25pbmcgQ0EwHhcNMjAwNjE2MDAwMDAw
# WhcNMjIwNzIyMTIwMDAwWjCBkTELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRQw
# EgYDVQQHEwtTYW4gTGVhbmRybzEVMBMGA1UEChMMT1NJc29mdCwgTExDMQwwCgYD
# VQQLEwNEZXYxFTATBgNVBAMTDE9TSXNvZnQsIExMQzEjMCEGCSqGSIb3DQEJARYU
# cGRlcmVnaWxAb3Npc29mdC5jb20wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEK
# AoIBAQDPSOGDHDmQTrdWSTB6jfvZ3+ngv2HwU/64ZUGKq+PbyQKcqeRI5MT2Fokj
# K9yp6JoVnipZaBZdjLRj//FuqDR/pNy3VZo1xmufKICqrSS6x2AxKb9l/6mcO/MF
# E2FgG0tND/xftCQlChB91GokCyiVNkwbLleB9uM6yn73ZZkiA0Chmjguipfal+hS
# 27vds5xYGLtcnqWcKcZR5pr838vDT+8zzrxoWQ8se3H9LHYLyCiwk+84mA1M//BW
# xaA7ERt1eJ3vLzYu3+ryH+GFiYEhJHu3FZjktEg5oZ25Vj7iwgTG+/CIMZsEDe5G
# SFvePn3jpMmEaPbOPfx8FVwh8XItAgMBAAGjggHFMIIBwTAfBgNVHSMEGDAWgBRa
# xLl7KgqjpepxA8Bg+S32ZXUOWDAdBgNVHQ4EFgQUmzSViihexjjLsHHW6j+r7Fxw
# U/gwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoGCCsGAQUFBwMDMHcGA1UdHwRw
# MG4wNaAzoDGGL2h0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9zaGEyLWFzc3VyZWQt
# Y3MtZzEuY3JsMDWgM6Axhi9odHRwOi8vY3JsNC5kaWdpY2VydC5jb20vc2hhMi1h
# c3N1cmVkLWNzLWcxLmNybDBMBgNVHSAERTBDMDcGCWCGSAGG/WwDATAqMCgGCCsG
# AQUFBwIBFhxodHRwczovL3d3dy5kaWdpY2VydC5jb20vQ1BTMAgGBmeBDAEEATCB
# hAYIKwYBBQUHAQEEeDB2MCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5kaWdpY2Vy
# dC5jb20wTgYIKwYBBQUHMAKGQmh0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNvbS9E
# aWdpQ2VydFNIQTJBc3N1cmVkSURDb2RlU2lnbmluZ0NBLmNydDAMBgNVHRMBAf8E
# AjAAMA0GCSqGSIb3DQEBCwUAA4IBAQAR/2LHTPvx/fBATBS0jBBhPEhlrpNgkWZ9
# NCo0wJC5H2V2CpokuZxA4HoK0YCsz2x68BpCnBOX3pdSWC+kQOvLyJayTQew+c/R
# sebGEVp9NNtsnpcFhjM3e7hqsQAm6rCIJWk0Q1sSyYnhnqHA/iS1DxNqZ/qZHx1k
# ise1+9bOefqB1YN+vtmPBlLkboKCklbrJmHSEn4cZNBHjq1yVYOPacuws+8kAEMh
# lDjG2NkfyqF72Jo90SFK7xgjE6euLbvmjGYRSF9h4V+aR6MaEcDkUe2aoCgCmnDX
# Q+9sIKX0AojqBVLFUNQpzelOdjGWNzdcMMSu8p0pNw4xeAbuCEHfMYIRHzCCERsC
# AQEwgYYwcjELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0IEluYzEZMBcG
# A1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTExMC8GA1UEAxMoRGlnaUNlcnQgU0hBMiBB
# c3N1cmVkIElEIENvZGUgU2lnbmluZyBDQQIQBlb6upLHhoprGBiRrHb6WzANBglg
# hkgBZQMEAgEFAKCBnjAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgorBgEE
# AYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgdRZLgRKEtse0
# kTvKXyDsEzCnVzhqcbIQeql90a7uvRgwMgYKKwYBBAGCNwIBDDEkMCKhIIAeaHR0
# cDovL3RlY2hzdXBwb3J0Lm9zaXNvZnQuY29tMA0GCSqGSIb3DQEBAQUABIIBAMKR
# gHL46ri0cO5RfStQPwb2Wov9zr2MNX1K5r7Ck9t5cRUbnxx4K8My3H/2Yke/LLPe
# 1bBRSZ03N7SY5IyaLtTiytcZ457hk3qYlZyae9eXMGJ83pyRgPbR22a+pAxWaEGE
# TuvU792u1GaPmTXzDBnCqSV1nge9KfASyJFmhDJzBq4AxEq+YBcIxoIYNyfmO+6A
# I508HRKycQP5XQgYzPyfUJg7yaf+QZvYzM4VRyH1OwmydkKnqBOz4VUgCAw0G82A
# dxdK8eIUpJl8ADEDZF8q28ODZWK4fOeYd4sM3cgQoFhvpUIQnWq3d5rAMJSpbHwq
# 0efYgt4lTw4YbqIR04ahgg7IMIIOxAYKKwYBBAGCNwMDATGCDrQwgg6wBgkqhkiG
# 9w0BBwKggg6hMIIOnQIBAzEPMA0GCWCGSAFlAwQCAQUAMHcGCyqGSIb3DQEJEAEE
# oGgEZjBkAgEBBglghkgBhv1sBwEwMTANBglghkgBZQMEAgEFAAQgtgnZ3OJ5JGqH
# Vy8scykc0QoUt3Y5ohIroBGqJYLp+wUCEAvjcwy8+l4P/nPtWXM3re0YDzIwMjAx
# MTA0MjA1NjI1WqCCC7swggaCMIIFaqADAgECAhAEzT+FaK52xhuw/nFgzKdtMA0G
# CSqGSIb3DQEBCwUAMHIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJ
# bmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xMTAvBgNVBAMTKERpZ2lDZXJ0
# IFNIQTIgQXNzdXJlZCBJRCBUaW1lc3RhbXBpbmcgQ0EwHhcNMTkxMDAxMDAwMDAw
# WhcNMzAxMDE3MDAwMDAwWjBMMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNl
# cnQsIEluYy4xJDAiBgNVBAMTG1RJTUVTVEFNUC1TSEEyNTYtMjAxOS0xMC0xNTCC
# ASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAOlkNZz6qZhlZBvkF9y4KTbM
# ZwlYhU0w4Mn/5Ts8EShQrwcx4l0JGML2iYxpCAQj4HctnRXluOihao7/1K7Sehbv
# +EG1HTl1wc8vp6xFfpRtrAMBmTxiPn56/UWXMbT6t9lCPqdVm99aT1gCqDJpIhO+
# i4Itxpira5u0yfJlEQx0DbLwCJZ0xOiySKKhFKX4+uGJcEQ7je/7pPTDub0ULOsM
# KCclgKsQSxYSYAtpIoxOzcbVsmVZIeB8LBKNcA6Pisrg09ezOXdQ0EIsLnrOnGd6
# OHdUQP9PlQQg1OvIzocUCP4dgN3Q5yt46r8fcMbuQhZTNkWbUxlJYp16ApuVFKMC
# AwEAAaOCAzgwggM0MA4GA1UdDwEB/wQEAwIHgDAMBgNVHRMBAf8EAjAAMBYGA1Ud
# JQEB/wQMMAoGCCsGAQUFBwMIMIIBvwYDVR0gBIIBtjCCAbIwggGhBglghkgBhv1s
# BwEwggGSMCgGCCsGAQUFBwIBFhxodHRwczovL3d3dy5kaWdpY2VydC5jb20vQ1BT
# MIIBZAYIKwYBBQUHAgIwggFWHoIBUgBBAG4AeQAgAHUAcwBlACAAbwBmACAAdABo
# AGkAcwAgAEMAZQByAHQAaQBmAGkAYwBhAHQAZQAgAGMAbwBuAHMAdABpAHQAdQB0
# AGUAcwAgAGEAYwBjAGUAcAB0AGEAbgBjAGUAIABvAGYAIAB0AGgAZQAgAEQAaQBn
# AGkAQwBlAHIAdAAgAEMAUAAvAEMAUABTACAAYQBuAGQAIAB0AGgAZQAgAFIAZQBs
# AHkAaQBuAGcAIABQAGEAcgB0AHkAIABBAGcAcgBlAGUAbQBlAG4AdAAgAHcAaABp
# AGMAaAAgAGwAaQBtAGkAdAAgAGwAaQBhAGIAaQBsAGkAdAB5ACAAYQBuAGQAIABh
# AHIAZQAgAGkAbgBjAG8AcgBwAG8AcgBhAHQAZQBkACAAaABlAHIAZQBpAG4AIABi
# AHkAIAByAGUAZgBlAHIAZQBuAGMAZQAuMAsGCWCGSAGG/WwDFTAfBgNVHSMEGDAW
# gBT0tuEgHf4prtLkYaWyoiWyyBc1bjAdBgNVHQ4EFgQUVlMPwcYHp03X2G5XcoBQ
# TOTsnsEwcQYDVR0fBGowaDAyoDCgLoYsaHR0cDovL2NybDMuZGlnaWNlcnQuY29t
# L3NoYTItYXNzdXJlZC10cy5jcmwwMqAwoC6GLGh0dHA6Ly9jcmw0LmRpZ2ljZXJ0
# LmNvbS9zaGEyLWFzc3VyZWQtdHMuY3JsMIGFBggrBgEFBQcBAQR5MHcwJAYIKwYB
# BQUHMAGGGGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBPBggrBgEFBQcwAoZDaHR0
# cDovL2NhY2VydHMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0U0hBMkFzc3VyZWRJRFRp
# bWVzdGFtcGluZ0NBLmNydDANBgkqhkiG9w0BAQsFAAOCAQEALoOhRAVKBOO5MlL6
# 2YHwGrv4CY0juT3YkqHmRhxKL256PGNuNxejGr9YI7JDnJSDTjkJsCzox+HizO3L
# eWvO3iMBR+2VVIHggHsSsa8Chqk6c2r++J/BjdEhjOQpgsOKC2AAAp0fR8SftApo
# U39aEKb4Iub4U5IxX9iCgy1tE0Kug8EQTqQk9Eec3g8icndcf0/pOZgrV5JE1+9u
# k9lDxwQzY1E3Vp5HBBHDo1hUIdjijlbXST9X/AqfI1579JSN3Z0au996KqbSRaZV
# DI/2TIryls+JRtwxspGQo18zMGBV9fxrMKyh7eRHTjOeZ2ootU3C7VuXgvjLqQhs
# Uwm09zCCBTEwggQZoAMCAQICEAqhJdbWMht+QeQF2jaXwhUwDQYJKoZIhvcNAQEL
# BQAwZTELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0IEluYzEZMBcGA1UE
# CxMQd3d3LmRpZ2ljZXJ0LmNvbTEkMCIGA1UEAxMbRGlnaUNlcnQgQXNzdXJlZCBJ
# RCBSb290IENBMB4XDTE2MDEwNzEyMDAwMFoXDTMxMDEwNzEyMDAwMFowcjELMAkG
# A1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0IEluYzEZMBcGA1UECxMQd3d3LmRp
# Z2ljZXJ0LmNvbTExMC8GA1UEAxMoRGlnaUNlcnQgU0hBMiBBc3N1cmVkIElEIFRp
# bWVzdGFtcGluZyBDQTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAL3Q
# Mu5LzY9/3am6gpnFOVQoV7YjSsQOB0UzURB90Pl9TWh+57ag9I2ziOSXv2MhkJi/
# E7xX08PhfgjWahQAOPcuHjvuzKb2Mln+X2U/4Jvr40ZHBhpVfgsnfsCi9aDg3iI/
# Dv9+lfvzo7oiPhisEeTwmQNtO4V8CdPuXciaC1TjqAlxa+DPIhAPdc9xck4Krd9A
# Oly3UeGheRTGTSQjMF287DxgaqwvB8z98OpH2YhQXv1mblZhJymJhFHmgudGUP2U
# Kiyn5HU+upgPhH+fMRTWrdXyZMt7HgXQhBlyF/EXBu89zdZN7wZC/aJTKk+FHcQd
# PK/P2qwQ9d2srOlW/5MCAwEAAaOCAc4wggHKMB0GA1UdDgQWBBT0tuEgHf4prtLk
# YaWyoiWyyBc1bjAfBgNVHSMEGDAWgBRF66Kv9JLLgjEtUYunpyGd823IDzASBgNV
# HRMBAf8ECDAGAQH/AgEAMA4GA1UdDwEB/wQEAwIBhjATBgNVHSUEDDAKBggrBgEF
# BQcDCDB5BggrBgEFBQcBAQRtMGswJAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3NwLmRp
# Z2ljZXJ0LmNvbTBDBggrBgEFBQcwAoY3aHR0cDovL2NhY2VydHMuZGlnaWNlcnQu
# Y29tL0RpZ2lDZXJ0QXNzdXJlZElEUm9vdENBLmNydDCBgQYDVR0fBHoweDA6oDig
# NoY0aHR0cDovL2NybDQuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEUm9v
# dENBLmNybDA6oDigNoY0aHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0
# QXNzdXJlZElEUm9vdENBLmNybDBQBgNVHSAESTBHMDgGCmCGSAGG/WwAAgQwKjAo
# BggrBgEFBQcCARYcaHR0cHM6Ly93d3cuZGlnaWNlcnQuY29tL0NQUzALBglghkgB
# hv1sBwEwDQYJKoZIhvcNAQELBQADggEBAHGVEulRh1Zpze/d2nyqY3qzeM8GN0CE
# 70uEv8rPAwL9xafDDiBCLK938ysfDCFaKrcFNB1qrpn4J6JmvwmqYN92pDqTD/iy
# 0dh8GWLoXoIlHsS6HHssIeLWWywUNUMEaLLbdQLgcseY1jxk5R9IEBhfiThhTWJG
# JIdjjJFSLK8pieV4H9YLFKWA1xJHcLN11ZOFk362kmf7U2GJqPVrlsD0WGkNfMgB
# sbkodbeZY4UijGHKeZR+WfyMD+NvtQEmtmyl7odRIeRYYJu6DC0rbaLEfrvEJStH
# Agh8Sa4TtuF8QkIoxhhWz0E0tmZdtnR79VYzIi8iNrJLokqV2PWmjlIxggJNMIIC
# SQIBATCBhjByMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkw
# FwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMTEwLwYDVQQDEyhEaWdpQ2VydCBTSEEy
# IEFzc3VyZWQgSUQgVGltZXN0YW1waW5nIENBAhAEzT+FaK52xhuw/nFgzKdtMA0G
# CWCGSAFlAwQCAQUAoIGYMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAcBgkq
# hkiG9w0BCQUxDxcNMjAxMTA0MjA1NjI1WjArBgsqhkiG9w0BCRACDDEcMBowGDAW
# BBQDJb1QXtqWMC3CL0+gHkwovig0xTAvBgkqhkiG9w0BCQQxIgQg5sb24L8MFOCS
# myRYoAuu9WLEDLa24VTqGM7ZUV+QsKMwDQYJKoZIhvcNAQEBBQAEggEARCk7PGnc
# eTEh5bvgQH28bSvuWMr37Oaucw78g1sdrk7p5LY9zGe7azsN3lAeO5iqUQ1vGdzA
# 7GL9c+ZiB/694Pa8JlBL69Jsx2V6jEA5RmFAqFkHMZOPx4xQIkeOW+I6Ssxob2zb
# ul3NxrfvEuMUm/FP7gwkN4Lq0TUsMepQ3DGjMNKQPOgaQXsp4ZzO+6z1AJMHUS+0
# iq4QdRdSklr4TEGRDte742xTNPY08i2q08vM20UZ47lgRGmjCWui/e09cfrYc0hQ
# n5IRNZiniGa5XsGQdVrJ+A4L7psEqsFbS4RSXm4o5BJp9iI9iGGHC8FPB71lhM28
# xRm6UIk4GjZWVQ==
# SIG # End signature block
