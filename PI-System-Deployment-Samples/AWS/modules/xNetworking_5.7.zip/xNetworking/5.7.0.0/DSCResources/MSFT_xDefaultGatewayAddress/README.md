# Description

The resource is responsible for creating and managing the Default Gateway for
an interface on a node.
