# Description

The xWaitForADDomain resource is used to wait for Active Directory to become available.
